typedef struct scheda* item;

#define NULLITEM 0

void input_item(item *x); 
void output_item(item x);
