#include <stdio.h>
#include <stdlib.h>
#include "item.h"
#include "list.h"

int main(void)
{
	list l; 
	item i;

}