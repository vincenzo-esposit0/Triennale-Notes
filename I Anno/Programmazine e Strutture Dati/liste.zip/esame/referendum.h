typedef struct seggio* referendum;

seggio newSeggio(void);
seggio inserSeggio(item s, list l);
int nosiRef(seggio s);