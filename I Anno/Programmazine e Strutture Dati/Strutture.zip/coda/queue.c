#include <stdio.h>
#include <stdlib.h>
#include "item.h" 
#include "queue.h"

struct node {
     item value;
     struct node *next;
};

struct c_queue {
     struct node *head,*tail;
     int numel;
};
queue newQueue(void)
{
     struct c_queue *q;
     q = malloc (sizeof(struct c_queue));
     if (q == NULL) 
	return NULL;

     q->numel = 0;
     q->head = NULL;
     q->tail = NULL;
     return q;
} 

int emptyQueue(queue q)
{
     if (q==NULL)
            return -1;
     return q->numel == 0;
}

int sizeQueue(queue q){

	if( q==NULLITEM ){

		return -1;

	} else {
	
		return q->numel;

	}

}

int enqueue(item val, queue q)
{
    if (q==NULL)
            return -1;

    struct node *nuovo;
    nuovo = malloc (sizeof(struct node));
    if (nuovo == NULL) return 0;
		nuovo->value=newItem();
		assign(nuovo->value, val);
    nuovo->next= NULL;

    if(q->head==NULL)
         q->head = nuovo;         //  caso coda vuota
    else 
         q->tail->next= nuovo;  //  caso coda non vuota

    q->tail = nuovo;                // tail punta al nuovo nodo
    (q->numel)++;                   // incrementare il numero di elementi
    return 1;     
}

item dequeue(queue q)
{
      if (q==NULL) return NULLITEM;

      if (q->numel == 0) return NULLITEM;    //  coda vuota

      item result = q->head->value;   //  item da restituire

      struct node *temp = q->head;   //  nodo da rimuovere
     
      q->head = q->head->next;        // q->head avanza
      free(temp);                 // liberiamo memoria nodo da rimuovere

      if(q->head==NULL)   // se la coda conteneva un solo elemento
             q->tail=NULL; 
      
      (q->numel)--;

      return result;
}

int printQueue(queue q){

	if(emptyQueue(q)){

		printf("Impossibile stampare una coda vuota!\n");
		return 0;

	}

	struct node *curr;
	curr=q->head;
	for(int i=0; i<q->numel; i++){
		if(curr!=NULLITEM){
			outputItem(curr->value);
			printf("\n");
			curr=curr->next;
		}
	}
return 1;
}

queue inputQueue(void){

	queue q=newQueue();
	item val=newItem();
	while(1){
		printf("digita valore:\n");
		inputItem(val);
		printf("\n");
		if(*val==FLAG){
			break;

		} else {
			enqueue(val,q);
		}
	}

	return q;

}

item getItem(queue q, int pos){

	int i;

	if(emptyQueue(q)){

		return NULLITEM;

	}

	if(pos<0 || pos>q->numel-1){

		return NULLITEM;

	}

	struct node* curr; 
	curr=q->head;


	for(i=0; i<pos; i++){

		curr=curr->next;

	}

	return curr->value;

}

int posItem(queue q, item val){

	int i, found=0;

	if(emptyQueue(q)){

		return -1;

	}

	struct node* curr=q->head;

	for(i=0; i<q->numel &&!found;i++){

		if(eq(curr->value, val)==1){

			found=1;

		} else  {

		curr=curr->next;

		}

	}

	if(found==1){

		return i-1;	
	
	} else {

		return -1;

	}

}

queue reverseQueue(queue q){

	queue q1=malloc(sizeof(struct c_queue));
	q1=newQueue();
	item val;
	int i;

	if(emptyQueue(q)){

		return q1;

	}

	for(i=q->numel-1;i>=0;i--){

		val=(getItem(q,i));
		if(!enqueue(val,q1)){

			return newQueue();

		}

	}
	

	return q1;

}

int delNode(queue q, int index){

	struct node* curr; 
	struct node* temp; 
	int i;	


	if(q==NULLITEM){

		printf("Puntatore nullo\n");
		return 0;

	}

	if(index<0 || index>q->numel-1){

		printf("Indice non valido!\n");
		return 0;

	} 

	if(emptyQueue(q)){

		printf("Impossibile eliminare un nodo da una coda vuota!\n");
		return 0;

	}

	if(index==0){

		temp=q->head;
		curr=temp->next;
		q->head=curr;
		free(temp->value);
		free(temp);
		q->numel--;
		return 1;

	} else {

	curr=q->head;
	for(i=0;i<index-1; i++){

		curr=curr->next;

	}

	temp=curr->next;
	curr->next=temp->next;
	free(temp->value);
	free(temp);
	q->numel--;
	return 1;

	}


}

queue cloneQueue(queue q){

	queue clone=newQueue();
	struct node *curr, *new;
	int i;	
	curr=q->head;
	new=malloc(sizeof(struct node));
	new->value=newItem();
	assign(new->value,curr->value);
	clone->head=new;
	new->next=NULLITEM;
	for(i=1; i<q->numel; i++){

		curr=curr->next;
		new->next=malloc(sizeof(struct node));
		new->next->value=newItem();
		assign(new->next->value, curr->value);
		new=new->next;
		new->next=NULLITEM;

	}

	clone->numel=q->numel;
	return clone;

}

int delOcc(queue q, item val){

	if(q == NULLITEM){

		return 0;

	}

	struct node *curr=q->head;

	while(curr != NULLITEM && eq(curr->value, val)==1){

		delNode(q, 0);
		curr=q->head;

	}

	if(curr != NULLITEM){

		struct node *temp=curr->next;

		while(temp != NULLITEM){

			if(eq(temp->value, val)==1){

				curr->next=temp->next;
				free(temp->value);
				free(temp);
				temp=curr->next;
				q->numel --;

			} else {

				curr=curr->next;
				temp=temp->next;
		
			}

		}

	}

	return 1;

}

int deleteQueue(queue q){

	struct node *temp1, *temp2;

	temp1=q->head;
	
	while(temp1 != NULLITEM){

		temp2=temp1;	
		temp1=temp1->next;
		free(temp2->value);
		free(temp2);
		q->numel --;

	}

	q->head=NULLITEM;
	q->tail=NULLITEM;

}

void destroyQueue(queue *q) {

	if(*q!=NULLITEM){

		deleteQueue(*q);
		free(*q); 
		*q=NULLITEM;

		}

}

int swap(queue q, int pos1, int pos2){

	int i;
	struct node* tmp1, *tmp2;
	tmp1=q->head;
	tmp2=q->head;
	item temp=newItem();

	if(pos1<0 || pos1>sizeQueue(q)-1 || pos2<0 || pos2>sizeQueue(q)-1){

		printf("L'indice inserito non è valido.\n");
		return 0;

	}

	if(pos1==pos2){
	
		return 1;
	
	}

	for(i=0; i<pos1; i++){

		tmp1=tmp1->next;	

	}

	for(i=0; i<pos2; i++){

		tmp2=tmp2->next;

	}

	assign(temp, tmp1->value);
	assign(tmp1->value, tmp2->value);
	assign(tmp2->value, temp);
	return 1;


}

void ordinamento(queue q){
	int i;
	int x=0;
	struct node* temp=q->head;
	do{
		x=0;
		temp=q->head;
		for(i=0;i<sizeQueue(q)-1;i++){
			if(eq(temp->value,temp->next->value)==0){
			//printf("ciao");
			swap(q,i,i+1);	
			x=1;
			}
			temp=temp->next;
		}
	}while(x==1);
}

int confronto(queue a,queue b){
struct node *temp1=a->head;
struct node *temp2=b->head;
	if(a==NULLITEM || b==NULLITEM) return 0;
	if(sizeQueue(a)!=sizeQueue(b)) return 0;
	else{
		for(int i=0;i<sizeQueue(a);i++){
			if(eq(temp1->value,temp2->value)!=1){
				return 0;}
			temp1=temp1->next;
			temp2=temp2->next;
			}
	}
return 1;
}

// cancella elementi in posizioni successive rispetto el

int successivi(queue q,item el)
{

int pos=posItem(q,el);
int i=pos+1;
int dim=q->numel;
while(i<dim){
delNode(q,pos+1);
i++;
}
return 1;
}

queue fusione(queue a, queue b)
{
	queue c=newQueue();
	item el=newItem();
	int i=0,j=0;
	while(a->numel>0)
	{		
		el=dequeue(a);
		if(contains(b,el)==1)
		{
			enqueue(el,c);
		}
	}

	
return c;
}

int contains(queue a,item el)
{
struct node *temp=a->head;
int trovato=0,i=0;
	if(emptyQueue(a))
	{
		return 0;
	}

	for(i=0;i<a->numel;i++)
	{
		if(eq(el,temp->value)==1)
		{
			return 1;
		}
		temp=temp->next;
	}
 return -1;

}
























