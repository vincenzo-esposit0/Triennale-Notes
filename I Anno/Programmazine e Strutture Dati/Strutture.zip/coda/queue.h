typedef struct c_queue *queue;

queue newQueue(void); //crea nuova coda

int sizeQueue(queue q); //dimensione coda

int emptyQueue(queue q); //restituisce -1 se vuota altrimenti 1

item dequeue(queue q); //restituisce l'item in testa e lo elimina dalla coda

int enqueue(item val, queue q);// aggiunge l'item in coda e restituisce -1se lista non allocata,0 se il nuovo nodo non è stato allocato, 1 se eè abdato tutto bene

int printQueue(queue q); //stampa della coda, restituisce 0 se non può altrimenti 1

queue inputQueue(void); //inserisce n elementi finchè non si digita il FLAG

item getItem(queue q, int pos); //restituisce l'elemento in posizione pos, altrimenti NULLITEM

int posItem(queue q, item val); //restituisce la posizione di val presente in coda altrimenti -1 (l'item di input va prima inizializzato con la funzione newItem)

queue reverseQueue(queue q);//restituisce la lista inversa altrimenti la lista vuota

int delNode(queue q, int index); //elimina un nodo in posizione index e restituisce 1 se ci riesce, altrimenti 0

queue cloneQueue(queue q); //restituisce la lista clonata, non bisogna inizializare la seconda lista 

int delOcc(queue q, item val); //cancella tutte le occorrenze di val e restituisce 1 se ci riesce.

int deleteQueue(queue q); //cancella tutta la coda in input ma non cancella il nodo di intestazione

void destroyQueue(queue *q); //cancella tutta la coda e il nodo di intestazione.

int swap(queue q, int pos1, int pos2);//ritorna 0 se non può invertire altrimenti 1

void ordinamento(queue q);

int confronto(queue a,queue b); // restituisce 1 se le code sono uguali, altrimenti 0

int successivi(queue q,item el); //restituisce la coda senza elementi successivi a el

int contains(queue a,item el);// ritorna 1 se el presente in a , altrimenti -1

queue fusione(queue a, queue b);//restituisce una nuova coda con gli elementi comuni alle 2 code


