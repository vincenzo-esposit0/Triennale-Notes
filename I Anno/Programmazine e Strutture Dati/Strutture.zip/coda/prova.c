#include<stdio.h>
#include"item.h"
#include"queue.h"
int main(){
int pos;
queue q1=newQueue();
queue q2=newQueue();
q1=inputQueue();
printf("\n secondo caricamento\n");
q2=inputQueue();
queue q3=newQueue();
q3=fusione(q1,q2);
printQueue(q3);
return 0;
}
