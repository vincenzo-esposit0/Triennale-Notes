typedef int *item;

#define NULLITEM NULL
#define FLAG 00000

item newItem(void);
int eq(item a, item b); //restituisce 1 se sono uguali, -1 se il primo è < del secondo, 1 se il primo è > del secondo
void inputItem(item a);
void outputItem(item a);
void assign(item a, item b);
