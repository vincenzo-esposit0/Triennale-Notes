#include<stdio.h>
#include"item.h"
#include"btree.h"
int main(){
item el=newItem();
item el2=newItem();
printf("digita elemento1");
inputItem(el);
Btree albero=newBtree();
Btree albero2=newBtree();
printf("digita elemento2");
inputItem(el2);
printf("\n");
albero=creaFoglia(el);
albero2=creaFoglia(el2);
printf("%d",generazione(albero,albero2));
return 0;
}
