#include "item.h"
typedef struct node *Btree;

// prototipi

item getItem(struct node *N); //restituisce l'item del nodo passato
void setItem(struct node *N, item el); //da un valore al nodo
Btree newBtree(void);
int emptyBtree(Btree T);
struct node *getRoot(Btree T);//da il puntatore al nodo radice
Btree consBtree(item val, Btree sx, Btree dx); //crea un albero con radice val a partire da due sottoalberi
Btree figlioSX(Btree T); //restituisce puntatore al figlio sx
Btree figlioDX(Btree T); //puntatore al figlio dx
Btree  inputBtree(void); //crea un albero e lo restituisce
Btree creaFoglia(item elem);
void visitaSimmetrica0(Btree T);
int altezza(Btree T);
int numFoglie(Btree T);
void outputBtree (Btree T);
void inorder(Btree T); //visita in preordine
int eqBtree(Btree a,Btree b); //ritorna 1 se due alberi sono uguali
int ricerca (Btree b,item val);// ritorna 1 se è presente l'item cercato
int generazione (Btree a,Btree b);// ritorna 1 se ci sono elementi in comune tra gli alberi
