#include <stdio.h>
#include <stdlib.h>
#include "item.h"
#include "list.h"

struct node{

	item value;
	struct node *next;

};

struct c_list{

	struct node *first;
	int size;

};


List newList(){

	List l;

	l=malloc(sizeof(struct c_list));
	if(!l){
	
		printf("La memoria non è sufficiente!\n");
		return NULLITEM;	

	}
	l->size=0;
	l->first=NULLITEM;
	return l;

	/*Il client dovrà controllare che i risultato non sia NULL*/


}



int sizeList(List l){

	if( l == NULLITEM ){

		return -1;

	} else {
	
		return l->size;

	}

}

int emptyList(List l){

	if(l == NULLITEM){

		return -1; //L è un puntatore nullo che non è stato ancora allocato come lista

	}	else {

		return (l->size==0);

	}

}


item getItem(List l, int pos){

	int i;

	if(emptyList(l)){

		return NULLITEM;

	}

	if(pos<0 || pos>l->size-1){

		return NULLITEM;

	}

	struct node* curr; 
	curr=l->first;


	for(i=0; i<pos; i++){

		curr=curr->next;

	}

	return curr->value;

}

int posItem(List l, item val){

	int i, found=0;

	if(emptyList(l)){

		return -1;

	}

	struct node* curr=l->first;

	for(i=0; i<l->size && !found; i++){

		if(eq(curr->value, val)){

			found=1;

		} else  {

		curr=curr->next;

		}

	}

	if(found){

		return i-1;	
	
	} else {

		return -1;

	}

}


List reverseList(List l){

	List l1=malloc(sizeof(struct c_list));
	l1=newList();
	item val;
	int i;

	if(emptyList(l)){

		return l1;

	}

	for(i=0; i<l->size; i++){

		val=(getItem(l, i));
		if(!insertList(l1, 0, val)){

			return newList();

		}

	}
	

	return l1;

}

List inputList(void){

	List l=newList();
	int stop=0, i=0;
	item val=newItem();

	while(1){

		inputItem(val);
		printf("\n");
		if(*val==FLAG){

			break;

		} else {

			insertList(l, i, val);
			i++;

		}



	}

	return l;

}

int insertList(List l, int index, item ele){

	struct node *curr=l->first, *new;
	int i;

	if(l == NULLITEM){

		printf("Puntatore nullo!\n");
		return 0;

	}

	if(index>l->size || index<0){

		printf("Posizione non trovata. Errore!\n");
		return 0;

	}


	if(index==0){

		new=malloc(sizeof(struct node));
		new->value=newItem();
		assign(new->value, ele);
		new->next=l->first;
		l->first=new;
		l->size ++;
		return 1;

	} else {

		curr=l->first;
		for(i=0; i<index-1; i++){

			curr=curr->next;

		}

		new=malloc(sizeof(struct node));
		new->value=newItem();
		assign(new->value, ele);
		new->next=curr->next;
		curr->next=new;
		l->size ++;
		return 1;

	}


}


int printList(List l){

	if(emptyList(l)){

		printf("Impossibile stampare una lista vuota!\n");
		return 0;

	}

	struct node *curr;
	curr=l->first;
	for(int i=0; i<l->size; i++){
		if(curr != NULLITEM){
			outputItem(curr->value);
			printf("\n");
			curr=curr->next;
		}
	}

}


int delNode(List l, int index){

	struct node* curr; 
	struct node* temp; 
	int i;	


	if(l==NULLITEM){

		printf("Puntatore nullo\n");
		return 0;

	}

	if(index<0 || index>l->size - 1){

		printf("Indice non valido!\n");
		return 0;

	} 

	if(emptyList(l)){

		printf("Impossibile eliminare un nodo da una lista vuota!\n");
		return 0;

	}

	if(index==0){

		temp=l->first;
		curr=temp->next;
		l->first=curr;
		free(temp->value);
		free(temp);
		l->size --;
		return 1;

	} else {

	curr=l->first;
	for(i=0; i<index-1; i++){

		curr=curr->next;

	}

	temp=curr->next;
	curr->next=temp->next;
	free(temp->value);
	free(temp);
	l->size --;
	return 1;

	}


}

List cloneList(List l){

	List clone=newList();
	struct node *curr, *new;
	int i;	

	curr=l->first;
	new=malloc(sizeof(struct node));
	new->value=newItem();
	assign(new->value, curr->value);
	clone->first=new;
	new->next=NULLITEM;
	
	for(i=1; i<l->size; i++){

		curr=curr->next;
		new->next=malloc(sizeof(struct node));
		new->next->value=newItem();
		assign(new->next->value, curr->value);
		new=new->next;
		new->next=NULLITEM;

	}

	clone->size=l->size;
	return clone;

}

int delOcc(List l, item val){

	if(l == NULLITEM){

		return 0;

	}

	struct node *curr=l->first;

	while(curr != NULLITEM && (eq(curr->value, val)==1)){

		delNode(l,0);
		curr=l->first;

	}

	if(curr != NULLITEM){

		struct node *temp=curr->next;

		while(temp != NULLITEM){

			if(eq(temp->value, val)==1){

				curr->next=temp->next;
				free(temp->value);
				free(temp);
				temp=curr->next;
				l->size --;

			} else {

				curr=curr->next;
				temp=temp->next;
		
			}

		}

	}

	return 1;

}


int deleteList(List l){

	struct node *temp1, *temp2;

	temp1=l->first;
	
	while(temp1 != NULLITEM){

		temp2=temp1;	
		temp1=temp1->next;
		free(temp2->value);
		free(temp2);
		l->size --;

	}

	l->first=NULLITEM;

}


void destroyList(List *l) {

	if(*l != NULLITEM){

		deleteList(*l);
		free(*l); 
		*l = NULLITEM;

		}

}



int swap(List l, int pos1, int pos2){

	int i;
	struct node* tmp1, *tmp2;
	tmp1=l->first;
	tmp2=l->first;
	item temp=newItem();

	if(pos1<0 || pos1>sizeList(l)-1 || pos2<0 || pos2>sizeList(l)-1){

		printf("L'indice inserito non è valido.\n");
		return 0;

	}

	if(pos1==pos2){
	
		return 1;
	
	}

	for(i=0; i<pos1; i++){

		tmp1=tmp1->next;	

	}

	for(i=0; i<pos2; i++){

		tmp2=tmp2->next;

	}

	assign(temp, tmp1->value);
	assign(tmp1->value, tmp2->value);
	assign(tmp2->value, temp);
	return 1;


}

void ordinamento(List l){
	int i;
	int x=0;
	struct node* temp=l->first;
	do{
		x=0;
		temp=l->first;
		for(i=0;i<sizeList(l)-1;i++){
			if(eq(temp->value,temp->next->value)==0){
			//printf("ciao");
			swap(l,i,i+1);	
			x=1;
			}
			temp=temp->next;
		}
	}while(x==1);
}



/*int cswap1(List l, int pos1, int pos2){

	struct node *t1=l->first, *t2=l->first, *t3=l->first;
	int i;

	if(pos1<0 || pos1>sizeList(l) || pos2<0 || pos2>sizeList(l)){

		printf("L'indice inserito non è valido.\n");
		return 0;

	}

	if(pos1==pos2){

		return 1;

	}

	
	for(i=0; i<pos1-1; i++){

		t1=t1->next;

	}

	for(i=0; i<pos1; i++){

		t2=t2->next;

	}

	for(i=0; i<pos2; i++){

		t3=t3->next;

	}
	

	if(pos1==0){

		l->first=t3;
		t2->next=t3->next;
		t3->next=t2;
		return 1;

	}

	
	t1->next=t3;
	t2->next=t3->next;
	t3->next=t2;

	return 1;

}
*/


/*int cswap2(List l, int pos1, int pos2){

	struct node *t1=l->first, *t2=l->first, *t3=l->first;
	int i;

	if(pos1<0 || pos1>sizeList(l) || pos2<0 || pos2>sizeList(l)){

		printf("L'indice inserito non è valido.\n");
		return 0;

	}

	if(pos1==pos2){

		return 1;

	}

	for(i=0; i<pos2-1; i++){

		t1=t1->next;

	}	

	
	for(i=0; i<pos2; i++){

		t2=t2->next;

	}


	for(i=0; i<pos1; i++){

		t3=t3->next;

	}


	if(pos2==0){

		l->first=t3;
		t2->next=t3->next;
		t3->next=t2;
		return 1;

	}

	
	t1->next=t3;
	t2->next=t3->next;
	t3->next=t2;
	return 1;

}*/


int confronto(List a,List b){
struct node *temp1=a->first;
struct node *temp2=b->first;
	if(a==NULLITEM || b==NULLITEM) return 0;
	if(sizeList(a)!=sizeList(b)) return 0;
	else{
		for(int i=0;i<sizeList(a);i++){
			if(eq(temp1->value,temp2->value)!=1){
				return 0;}
			temp1=temp1->next;
			temp2=temp2->next;
			}
	}
return 1;
}



