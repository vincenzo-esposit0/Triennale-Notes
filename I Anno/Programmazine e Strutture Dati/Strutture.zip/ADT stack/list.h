#include "item.h"

typedef struct c_list *List;

List newList(); //crea una nuova lista e la restituisce
int sizeList(List l); //dimensione lista
int emptyList(List l); //ritorna 1 se lista vuota altrimenti 0 
item getItem(List l, int pos); //restituisce l'item in posizione pos,(pos parte da 0)
int posItem(List l, item val); //restituisce la posizione di val in lista altrimenti -1 (l'item di input va prima inizializzato con la funzione newItem)
List reverseList(List l1); //restituisce la lista inversa
List inputList(void); //ritorna una lista caricata finchè non si digita 100399
int insertList(List l1, int index, item j); //inserisce un elemento in posizione index,restituisce 0 se fallisce altrimenti 1
int printList(List l); //stampa tutta la lista e restituisce 0 se non può
int delNode(List l1, int index); //ritorna 0 se la posizione non è valida o non riesce a eliminare,altrimenti cancella il nodo e restituisce 1
List cloneList(List l); //restituisce la lista clonata
int delOcc(List l, item val); //cancella tutte le occorrenze di un item,restituisce 0 se puntatore null altrimenti 1
int deleteList(List l); //cancella tutta la lista in input ma non cancella il nodo di intestazione
void destroyList(List *l); //cancella tutta la lista e il nodo di intestazione.
int swap(List l, int pos1, int pos2); //ritorna 0 se non può invertire altrimenti 1
//int cswap1(List l, int pos1, int pos2); //
//int cswap2(List l, int pos1, int pos2);
void ordinamento(List l);
int confronto(List a,List b);
