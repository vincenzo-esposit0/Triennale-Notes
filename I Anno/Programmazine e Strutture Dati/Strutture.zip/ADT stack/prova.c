#include<stdio.h>
#include"item.h"
#include"stack.h"
int main(){
stack pila=newStack();
item el=newItem();
for(int i=0;i<4;i++){
	printf("digita valore:\n");
	inputItem(el);
 	push(el,pila);
}
printf("caricamento effettuato\n");
for(int i=0;i<4;i++){
printf("elemento %d:",i);
outputItem(top (pila));
pop (pila);
printf("\n");
}

return 0;
}
