#include <stdio.h>
#include <stdlib.h>
#include "item.h"
#include "bst.h"


struct node {
     item value;
     struct node *left;
     struct node *right;
};

item getItem(struct node *N)
{
      if (N == NULL)  return NULLITEM;
      return N->value;
}

void setItem(struct node *N, item el)
{
     if (N==NULL) return;
     N->value = el;  // correttezza di =
}                             // dipende dal tipo item

BST newBST (void)
{
     return NULL;
}
 
int emptyBST (BST T)
{
     return T == NULL;
}

BST figlioSX(BST T)
{
      if (T != NULL)    
	return  T->left;
      else 
             return NULL;
}

BST figlioDX(BST T)
{
      if (T != NULL)    
	return  T->right;
      else 
             return NULL;
}

int contains(BST T, item val)
{
      if (T == NULL)  return 0;
      if (eq(val, getItem(T))==1)  return 1;
      if (eq(val, getItem(T))==-1)
            return (contains(figlioSX(T), val));
      else
            return (contains(figlioDX(T), val));
}

BST creaFoglia(item elem)
{       
      struct node *N;
      N = malloc (sizeof(struct node));
      if (N == NULL)   return NULL;
      setItem (N, elem);
      N -> left = NULL;
      N -> right = NULL;
      return N;
}

BST insert(BST T, item elem)
{       
    if (T==NULL)    return creaFoglia(elem);
    else   if (eq(elem, getItem(T))==-1)
                  T->left = insert(T->left, elem);
              else  (eq(elem, getItem(T))==0)
                  T->right = insert(T->right, elem);
    return T;
}

struct node * minValue(struct node* node)
{
    struct node* current = node;
    while (current->left != NULL)
        current = current->left;
    return current;
}

struct node * maxValue(struct node* node)
{
    struct node* current = node;
    while (current->right != NULL)
        current = current->right;
    return current;
}

struct node* deleteNode(struct node* root, item key)
{
    if (root == NULL) return root;
 
    if (eq(key, root->value)==-1)
        root->left = deleteNode(root->left, key);
    else if (eq(root->value, key)==-1)
        root->right = deleteNode(root->right, key);
 
    else
    {
        if (root->left == NULL)
        {
            struct node *temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL)
        {
            struct node *temp = root->left;
            free(root);
            return temp;
        }
        struct node* temp = minValue(root->right);
        root->value = temp->value;
// Delete the inorder successor
        root->right = deleteNode(root->right, temp->value);
    }
    return root;
}



int verifica(BST t){

if(t==NULL) return 1;
if(figlioSX(t)==NULL || figlioDX(t)==NULL)return 0; 
item minore,maggiore;
assign(minore,getItem(maxValue(figlioSX(t))));
assign(maggiore,getItem(maxValue(figlioDX(t))));
if ((eq(getItem(t),minore)==0) && (eq(getItem(t),maggiore)==-1)) return (verifica(figlioSX(t)) && verifica(figlioDX(t)));
else return 0;
}












