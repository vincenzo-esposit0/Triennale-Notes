#include<stdio.h>
#include"item.h"
#include"bst.h"
int main(){
item el=newItem();
item el2=newItem();
printf("digita elemento1");
inputItem(el);
BST albero=newBST();
BST albero2=newBST();
printf("digita elemento2");
inputItem(el2);
printf("\n");
albero=creaFoglia(el);
albero2=creaFoglia(el2);
printf("%d",contains(albero,el2));
return 0;
}
