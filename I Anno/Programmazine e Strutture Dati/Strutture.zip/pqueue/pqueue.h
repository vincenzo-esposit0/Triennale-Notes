// file PQueue.h


typedef struct c_PQ *PQueue;

// prototipi

PQueue newPQ(void);

int emptyPQ(PQueue q);

int getMax(PQueue q); //restituisce la chiave con valore massimo, cioè la prima, ma non la cancella 

int deleteMax(PQueue q); //elimina la chiave con valore massimo e mette in cima la chiave più pesante , ritorna 1

int insert (PQueue q, int key); //inserisce una chiave nella coda

int eliminazione(PQueue p,int el); //elimina la chiave dalla coda se preente, o la chiave minore più vicina

void ordinaV(int v[],int dim); // ordina un vettore a partire passando gli elementi in coda e poi dinuovo in vettore.

void print(PQueue p);
