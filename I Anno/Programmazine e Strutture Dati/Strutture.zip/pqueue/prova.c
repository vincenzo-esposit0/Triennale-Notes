#include<stdio.h>
#include"item.h"
#include"pqueue.h"
int main(){
int a=0;
PQueue p=newPQ();
for(int i=0;i<5;i++) {
printf("digita valore:");
scanf("%d",&a);
printf("\n");
insert(p,a);
}
printf("%d\n",getMax(p));
deleteMax(p);
printf("%d\n",getMax(p));
return 0;
}
