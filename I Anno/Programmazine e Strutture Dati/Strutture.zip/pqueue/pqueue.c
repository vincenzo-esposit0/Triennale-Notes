#include <stdio.h>
#include <stdlib.h>
#include "pqueue.h"
#define MAXPQ 50

struct c_PQ {
     int vet[MAXPQ];
     int numel;
};

static void scendi (PQueue q);
static void sali (PQueue q);

PQueue newPQ(void)
{
     PQueue q;
     q = malloc (sizeof(struct c_PQ));
     if (q == NULL) return NULL;
     q->numel = 0;
     return q;
}

int emptyPQ(PQueue q)
{
     if (!q)  return 1;
     return q->numel == 0;
}


int getMax(PQueue q)
{
     return q->vet[1];
     // NON VERIFICA LA
     // PRECONDIZIONE
     // LA CODA NON PUO’
     // ESSERE VUOTA
}

int deleteMax(PQueue q)
{
     if (!q || q->numel==0) return 0;   // CODA VUOTA

     q->vet[1] = q->vet[q->numel];  //SPOSTO L’ULTIMO ELEMENTO
     q->numel --;                               // IN POSIZIONE 1

     scendi(q);      // RIAGGIUSTO LO HEAP SCENDENDO

     return 1;
} 

static void scendi (PQueue q)
{
    int temp, n=q->numel, i=1, pos;

    while (1)
    {
       if (2*i+1 <= n)               // IL NODO CORRENTE HA 2 FIGLI
                  pos =  (q->vet[i*2] > q->vet[i*2+1])  ?   i*2  :   i*2+1;

       else  if (2*i <= n)          // IL NODO CORRENTE HA 1 FIGLIO
                  pos = 2*i;
       else  break;                  // IL NODO CORRENTE NON HA FIGLI
         
       if (q->vet[pos] > q->vet[i])     // SCAMBIO LE CHIAVI E PROSEGUO 
       {
             temp = q->vet[i];
             q->vet[i] = q->vet[pos];
             q->vet[pos] = temp;
             i = pos;
       }
       else
           break;   // NON CI SONO PIU’ SCAMBI DA FARE, MI FERMO 
     }
}

int insert (PQueue q, int key)
{

     if (!q || q->numel==MAXPQ) return 0; // CODA PIENA 

     q->numel++;
     q->vet[q->numel] = key;   // INSERISCI IN ULTIMA POSIZIONE
     
     sali(q);     // AGGIUSTA LO HEAP RISALENDO

     return 1;
} 

static void sali (PQueue q)
{
    int temp, pos=q->numel, i=pos/2;

    while (pos>1)
    {
                
       if (q->vet[pos] > q->vet[i])
       {
             temp = q->vet[i];
             q->vet[i] = q->vet[pos];
             q->vet[pos] = temp;
             pos = i;
             i = pos/2;
       }
       
       else
             break;
     }
}

void ordinaV(int v[],int dim){

	int i=1;
	PQueue q=newPQ();

	for(int i=0;i<dim;i++){
		insert(q,v[i]);
	}

	for(int i=dim-1;i>dim;i--){
		v[i]=getMax(q);
	}
}



void print(PQueue p){

for(int i=1;i<p->numel+1;i++){
	printf("elemento %d:%d\n",i,p->vet[i]);
}


}

int eliminazione(PQueue p,int el){ //passare una coda gia carica
	int v[p->numel];
	int max=-125;
	int i=1;
	int size=p->numel,dim=0;
	for(i=1;i<size;i++)
	{
		if(p->vet[1]==el){
			deleteMax(p);
			break;
		}
		else{ 	
			v[i]=p->vet[1];
			deleteMax(p);
			dim++;		
			if(p->vet[1]<=el && p->vet[1]>max) max=p->vet[1];
		}
	}

	if(max==-125)
	{ 	
		printf("nessuna chiave da eliminare...\n"); 
		return -1;
	}

	printf("chiave da eliminare:%d\n",max);

	if(max<el) deleteMax(p);

	for(int j=1;j<dim+1;j++)
	{
		printf("carico eleemento:%d\n",v[j]);
		insert(p,v[j]);
	}

	printf("coda ricaricata...\n");
	print(p);
	return 1;

}




























