package com.example.prova.lightlife;

import android.app.Activity;
import android.os.Bundle;

public class HomePageNegoziante extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page_negoziante);

    }
}
