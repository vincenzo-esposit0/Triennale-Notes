package safemeeting.proxy;

import java.io.InputStream;

public interface Image {
	
	InputStream display();
	
}
