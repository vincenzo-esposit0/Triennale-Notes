package esposito.vincenzo.miranda.donato;

/*
 * Modifica attributo nell'entit� Attivita: CodiceAttivit� senza Auto-Increment
 * Modifica dei dati nell'entit� Centro: Denominazione del centro scritta senza nessuno spazio
 * Modifica dei dati nelle entit� Prenotazione, Attivita, Svolgimento: l'attributo durata � stato modificato da minuti in ore
 */

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

public class ApplicazioneCentri {
	
	public static ArrayList<DataCompleta> dateList = new ArrayList<DataCompleta>();

	/**
	 * @return the dateList
	 */
	public ArrayList<DataCompleta> getDateList() {
		return dateList;
	}

	/**
	 * @param dateList the dateList to set
	 */
	public void setDateList(ArrayList<DataCompleta> dateList) {
		this.dateList = dateList;
	}



	public static void main(String[] args) {

		int expression;
		Scanner in = new Scanner(System.in);
		
		
		System.out.println("Q1: Prenotazione di una struttura. \n");
		System.out.println("Q2: Verifica della possibilit� di prenotare una struttura per un determinato giorno dell�anno ad una determinata ora.\n");
		System.out.println("Q3: Visualizzazione degli orari disponibili per prenotare una struttura in un determinato giorno.\n");
		System.out.println("Q4: Visualizzazione dei giorni disponibili per prenotare una struttura in un determinato orario.\n");
		System.out.println("Q5: Svolgimento di un�attivit�.\n");
		System.out.println("Q6: Visualizzazione per ogni attivit� del numero di ore in cui sono state svolte in un anno.\n");
		System.out.println("Q7: Abilitazione di un nuovo centro allo svolgimento di un�attivit�.\n");
		System.out.println("Q8: Assunzione di un nuovo allenatore.\n");
		System.out.println("Q9: Visualizzazione della struttura in cui sono state svolte il maggior numero di attivit� nell�anno corrente.\n");
		System.out.println("Q10: Visualizzazione di tutti gli allenatori specializzati in una determinata disciplina.\n");
		System.out.println("Q11: Cancellazione di uno dei responsabili di un centro, con elezione di un nuovo responsabile.\n");
		System.out.println("Q12: Modifica dell�orario della prenotazione di una struttura (se possibile).\n");
		System.out.println("Q13: Caricamento di un corso organizzato da un centro, con l�assegnazione di eventuali allenatori.\n");
		System.out.println("Q14: Stampa annuale di un report che mostri i dati delle strutture, incluso il numero totale di giorni in cui � stata libera.\n");
		System.out.println("Q15: Stampa annuale di un report che mostri i dati delle strutture, incluso il numero di ore in cui sono state occupate negli ultimi due anni.\n");
		
		System.out.println("SCEGLI LA QUERY CHE VUOI ESEGUIRE:  ");
		
		expression = in.nextInt();
		
		switch(expression) {
		   case  1:
			   ApplicazioneCentri.Query1();
		      break;
		      
		   case  2:
			   ApplicazioneCentri.Query2();
		      break;
		      
		   case  3:
			   ApplicazioneCentri.Query3();
			  break;
		      
		   	case  4:
			   ApplicazioneCentri.Query4();
			  break;
		      
		   	case  5:
		   		ApplicazioneCentri.Query5();
		   	  break;
		   
		   case 6:
			   ApplicazioneCentri.Query6();
			  break; 
		      
		   case 7:
			   ApplicazioneCentri.Query7();
			  break; 
			      
		   case 8:
			   ApplicazioneCentri.Query8();
			  break;
			  
		   case 9: 
			   ApplicazioneCentri.Query9();
			   break;
		      
		   case  10:
			   ApplicazioneCentri.Query10();
		      break;
		      
		   case  11:
			   ApplicazioneCentri.Query11();
		      break;
		   
		   case  12:
			   ApplicazioneCentri.Query12();
		      break;
		     
		   case  13:
			   ApplicazioneCentri.Query13();
		      break;
		      
		   case  14:
			   ApplicazioneCentri.Query14();
		      break;
		      
		   case  15:
			   ApplicazioneCentri.Query15();
		      break;
		
		   default : System.out.println("Scelta errata");
		   
		}
		
		
	}

	/*
	 * Connessione al db 
	 */
	
	public static Connection Connessione() {
		Connection con=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/progettocentri"
					+ "?user=root&password=");		
		}
		catch(Exception e){
				System.out.println("Connessione fallita");
		}
		
		return con;
	}

	/*
	 * Struttura per la gestione delle date e degli orari 
	 */
	private static void initDate(int anno, int mese, int giorno) {
		Calendar startDate = Calendar.getInstance();
		startDate.set(Calendar.YEAR, anno);
		startDate.set(Calendar.MONTH, mese); //gennaio e 0
		startDate.set(Calendar.DAY_OF_MONTH, giorno);
		
		
		Calendar endDate = Calendar.getInstance();
		endDate.set(Calendar.YEAR, anno);
		endDate.set(Calendar.MONTH, mese); //dicembre e 11
		endDate.set(Calendar.DAY_OF_MONTH, giorno);
		
		String patternData = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(patternData);

		while (startDate.before(endDate)) {
			//System.out.println("Data corrente: " + startDate.getTime());
			
			for (int i = 9 ; i<24; i++)
			{
				DataCompleta dc = new DataCompleta();
				dc.setData( simpleDateFormat.format(startDate.getTime()) );
				
				String ora = String.valueOf(i);
				dc.setOra(ora);
				dateList.add(dc);
			}
			
			
			startDate.add(Calendar.DAY_OF_MONTH, 1);
		}
		
	}
	
	
	/*
	 * Gestione del periodo di date nelle quali mostrare le prenotazioni possibili per un determinato orario
	 */
	
	private static void initDate() {
		
		Calendar startDate = Calendar.getInstance();
		startDate.set(Calendar.YEAR, 2019);
		startDate.set(Calendar.MONTH, 11); //gennaio e 0
		startDate.set(Calendar.DAY_OF_MONTH, 1);
		
		
		Calendar endDate = Calendar.getInstance();
		endDate.set(Calendar.YEAR, 2019);
		endDate.set(Calendar.MONTH, 11); //dicembre e 11
		endDate.set(Calendar.DAY_OF_MONTH, 31);
		
		String patternData = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(patternData);

		while (startDate.before(endDate)) {
			//System.out.println("Data corrente: " + startDate.getTime());
			
			
			
			for (int i = 9 ; i<24; i++)
			{
				DataCompleta dc = new DataCompleta();
				dc.setData( simpleDateFormat.format(startDate.getTime()) );
				
				String ora = String.valueOf(i);
				dc.setOra(ora);
				dateList.add(dc);
			}
			
			
			startDate.add(Calendar.DAY_OF_MONTH, 1);
		}
	}

	/*
	 * 	Lista delle query:
	 */

	/*
	 * QUERY 1
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * codice fiscale del segretario: SPSVCN00E04C129S
	 * struttura scelta: 3
	 * codice struttura: 1
	 * nome centro: Olimpia
	 * data prenotazione: 2020-05-04
	 * ora prenotazione: 9
	 * durata prenotazione: 1
	 * codice attivit�: 1
	 */
	
	public static void Query1() {
		
		Scanner in = new Scanner(System.in);
		
		Connection con = Connessione();
		
		try {
			
			System.out.println("Inserisci il codice fiscale del segretario : ");
			String codfis=in.next();
			Statement query0 = con.createStatement();
			ResultSet result0 =query0.executeQuery("Select * from segretario "
					+ "where CodiceFiscale ='"+codfis+"'");
			if(result0.next())System.out.println("Il segretario esiste!\n");
			else throw new Exception("Il segretario non esiste!\n");
			
			String tipo1=null, tipo2=null, tipo3=null;
			System.out.println("La struttura che si intende prenotare quali requisiti deve avere:  "
					+ "\n1)Campo all'aperto"
					+ "\n2)Campo al chiuso"
					+ "\n3)Sala con attrezzature"
					+ "\n4)Sala senza attrezzature"
					+ "\nScelta : ");
			int att=in.nextInt();
			
			switch(att) {
				case 1:
					
					tipo1="campo";
					tipo2="NULL";
					tipo3="aperto";
						break;
						
				case 2: 
					
					tipo1="campo";
				    tipo2="NULL";
				    tipo3="chiuso";
				        break;
				        
				case 3: 
					
					tipo1="sala";
				    tipo2="si";
				    tipo3="NULL";
				      	break;
				      	
		        case 4: 
		        	
		        	tipo1="sala";
		        	tipo2="no";
		        	tipo3="NULL";
		        		break;
		        		
	 		}
			
			Statement query9 = con.createStatement();
			ResultSet result9 =query9.executeQuery("Select * "
					+ "from struttura "
					+ "where Tipo ='"+tipo1+"' "
					+ "and PresenzaAttrezzatura='"+tipo2+"' "
					+ "and TipologiaCampo='"+tipo3+"'");
			
			while(result9.next()) {
				
				if(tipo2=="NULL") {
					
					System.out.println("Codice Struttura 		:"+result9.getString("CodiceStruttura"));
					System.out.println("Nome Centro      		:"+result9.getString("NomeCentro"));
					System.out.println("Tipo Struttura   		:"+result9.getString("Tipo")+"");
					System.out.println("Tipologia Campo   		:"+result9.getString("TipologiaCampo")+"\n");
				
				}
				else {
				
					System.out.println("Codice Struttura 		:"+result9.getString("CodiceStruttura"));
					System.out.println("Nome Centro      		:"+result9.getString("NomeCentro"));
					System.out.println("Tipo Struttura   		:"+result9.getString("Tipo")+"");
					System.out.println("Presenza Attrezzature   	:"+result9.getString("PresenzaAttrezzatura")+"\n");
				
				}
			}
			
			System.out.println("Inserisci il codice struttura : ");
			String codice=in.next();
			
			System.out.println("Inserisci il nome centro : ");
			String nomecentro=in.next();
			
			Statement query1 = con.createStatement();
			ResultSet result1 =query1.executeQuery("Select * from struttura "
					+ "where CodiceStruttura ='"+codice+"' "
					+ "and NomeCentro ='"+nomecentro+"' "
					+ "and Tipo ='"+tipo1+"'"
					+ "and PresenzaAttrezzatura='"+tipo2+"' "
					+ "and TipologiaCampo='"+tipo3+"'");
			if(result1.next())System.out.println("Struttura valida!\n");
			else throw new Exception("Struttura non valida\n");
			
			System.out.println("Inserisci la data : ");
			String data=in.next();
			
			int orai;
			while(true) {
			
				System.out.println("Dammi l'ora (9 - 23) : ");
				orai=in.nextInt();
			
				if(9<=orai&&orai<=23)break;
			}
			String ora=""+orai+":00:00";
			
			int duratai;
			while(true) {
			
				System.out.println("Dammi durata max ("+(24-orai)+"): ");
				duratai=in.nextInt();
			
				if(duratai<=(24-orai))
					break;
			}
			
			Statement query = con.createStatement();
			ResultSet result =query.executeQuery("select * from prenotazione "
					+ "where DataP ='"+data+"' "
					+ "and CodiceStruttura ='"+codice+"' "
					+ "and NomeCentro ='"+nomecentro+"'");
			
			while(result.next()) {
				
				Time orap = result.getTime("OraP");
				int orain=orap.getHours();
				int dur=result.getInt("Durata");
				if(orai<=orain && orain<(orai+duratai))
					throw new Exception("La struttura non puo essere prenotata!\n");
				
				if(orain<=orai && orai<(orain+dur))
					throw new Exception("La struttura non puo essere prenotata!\n");
			}
			String durata=""+duratai+"";
			
			System.out.println("Inserisci la descrizione : ");
			String descrizione=in.next();
			
			System.out.println("Inserisci il codice attivit� : ");
			String attivita=in.next();
			
			Statement query2 = con.createStatement();
			ResultSet result2=query2.executeQuery("select Istruttore from presiede "
					+ "where CodiceAttivita ='"+attivita+"'");
			
			while(result2.next()) {
				
				String codicefiscale = result2.getString("Istruttore");
				
				Statement query3 = con.createStatement();
				ResultSet result3=query3.executeQuery("select CodiceAttivita from presiede "
						+ "where Istruttore ='"+codicefiscale+"'");
				
				while(result3.next()) {
					
					String codicecontrollo = result3.getString("CodiceAttivita");
					
					Statement query4 = con.createStatement();
					ResultSet result4=query4.executeQuery("select * from prenotazione "
							+ "where DataP ='"+data+"'"
							+ "and OraP ='"+ora+"'"
							+ "and CodiceAttivita ='"+codicecontrollo+"'");
					
					if(result4.next())
						throw new Exception("Impossibile effettuare la prenotazione "
							+ "dato che l'istruttore "+codicefiscale+" dell'attivita che si vuole "
									+ "prenotare � gi� impegnato in data "+data+" in ora "+ora);
				}	
			}
			
			System.out.println("E' possibile effetture la prenotazione; \n"
					+ "Elaborazione in corso..");
			
				String que="INSERT INTO prenotazione"
						+ "(`DataP`, `OraP`, `Durata`, `Descrizione`, `Segretario`," + 
						"`CodiceStruttura`, `NomeCentro`, `CodiceAttivita`)"
						+ "VALUES(?,?,?,?,?,?,?,?)";
			    PreparedStatement pstmt = con.prepareStatement(que,Statement.RETURN_GENERATED_KEYS); 
			        
			        pstmt.setString(1, data);
			        pstmt.setString(2, ora);
			        pstmt.setString(3, durata);
			        pstmt.setString(4, descrizione);
			        pstmt.setString(5, codfis);
			        pstmt.setString(6, codice);
			        pstmt.setString(7, nomecentro);
			        pstmt.setString(8, attivita);
			        int affectedRows = pstmt.executeUpdate();
			        
			        System.out.println("Prenotazione effettuata con successo!");
				
		}
			
		catch (Exception e){
			System.out.println(e);
			System.out.println("Errore nell'interrogazione");
		}
	}

	/*
	 * QUERY 2
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * codice struttura: 1
	 * nome centro: Olimpia
	 * data prenotazione: 2020-04-04
	 * ora prenotazione: 9
	 * 
	 */
	
	public static void Query2() {
		Connection con = null ;
		
		con=Connessione();
		
		Scanner in = new Scanner(System.in);
	
		try {
			
			System.out.println("Q2: Verifica della possibilit� di prenotare una struttura per un determinato giorno dell�anno ad una determinata ora.  \n");
			
			System.out.println("Inserisci il codice struttura : ");
			String codice = in.next();
			System.out.println("Inserisci il nome del centro : ");
			String nomeCentro = in.next();
			System.out.println("Inserisci la data : ");
			String data = in.next();
			System.out.println("Inserisci l'ora : ");
			String ora = in.next();
			
			Statement query = con.createStatement();
	
			ResultSet result =query.executeQuery("select * from prenotazione "
					+ "where DataP ='"+data+"' "
					+ "and OraP ='"+ora+"' "
					+ "and CodiceStruttura ='"+codice+"' "
					+ "and NomeCentro ='"+nomeCentro+"'");
	
			if(result.next())
				System.out.println("Impossibile effetture la prenotazione dato che \n la struttura : "+codice
					+" del centro : "+nomeCentro+"� gia impegnata\n in data : "+data
					+"\n in ora : "+ora);
			else System.out.println("E' possibile effetture la prenotazione la struttura non � impegnata.");
		
		}
	
		catch (Exception e){
			
			//System.out.println (e);
			System.out.println("Errore nell'interrogazione");
	}
	}

	/*
	 * QUERY 3
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * anno: 2019
	 * mese: 12
	 * giorno: 09
	 * codice struttura: 1
	 * nome centro: Olimpia
	 * 
	 */
	
	public static void Query3() {
		Connection con = null ;
		
		con=Connessione();
		
		Scanner in = new Scanner(System.in);
		
		try {
			
			System.out.println("Q3: Visualizzazione degli orari disponibili per prenotare una struttura in un determinato giorno.\n");
		
			System.out.println("Inserisci anno : ");
			int anno=in.nextInt();
			
			System.out.println("Inserisci il mese : ");
			int mese=in.nextInt();
			
			System.out.println("Inserisci il giorno : ");
			int giorno=in.nextInt();
			
			System.out.println("Inserisci il codice della struttura : ");
			String codiceStruttura=in.next();
			
			System.out.println("Inserisci il nome del centro: ");
			String nCentro=in.next();
			
			Statement query = con.createStatement();
	
			String dataQuery = String.valueOf(anno)+"-"+String.valueOf(mese)+"-"+String.valueOf(giorno);
			ResultSet result = query.executeQuery("SELECT OraP, DataP, CodicePrenotazione, CodiceStruttura, NomeCentro"
					+ " FROM prenotazione "
					+ " WHERE DataP= '"+dataQuery+"' AND CodiceStruttura = '"+codiceStruttura+"' "
					+ " AND NomeCentro='"+nCentro+"' ");
		
			while(result.next()){
				
				String ora = result.getString("OraP");
				
				String data = result.getString("DataP");
				
				String codicePrenotazione = result.getString("CodicePrenotazione");
				
				String cStruttura = result.getString("CodiceStruttura");
				
				String nomeCentro = result.getString("NomeCentro");
				
				initDate(anno, mese-1, giorno);
				
				
				DataCompleta dataC = new DataCompleta();
				dataC.setData(data);
				dataC.setOra(ora.substring(0, 2));
				System.out.println ("La struttura � prenotata alle ore: " + dataC.getOra());
				
				
				if (dateList.contains(dataC)) {
					dateList.remove(dataC);
				}
				
				//System.out.println(codicePrenotazione +"\t : " +ora+"\t" +data+ "\t \n");
	
			}
			
			/*
			 * Se la dateList � vuota il giorno non � stato prenotato e quindi � completamente disponibile
			 */
			if (dateList.isEmpty()) {
				System.out.println("Il giorno selezionato e completamente disponibile");
				System.out.println("Query eseguita correttamente");
			}else {
				System.out.println("Elenco delle prenotazioni disponibili: ");
				for (DataCompleta dc : dateList) {
					System.out.println("Data: " + dc.getData() + ", Ora: " + dc.getOra());
				}
			}
		
		}
	
		catch (Exception e){
			System.out.println(e);
			System.out.println("Errore nell'interrogazione");
	}
	}

	/*
	 * QUERY 4
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * orario: 15:00:00
	 * codice struttura: 1
	 * nome centro: Olimpia
	 * 
	 */
	
	public static void Query4() {
		Connection con = null ;
		
		con=Connessione();
		
		Scanner in = new Scanner(System.in);
	
		try {
			
			System.out.println("Q4: Visualizzazione dei giorni disponibili per prenotare una struttura in un determinato orario. \n");
			
			
			System.out.println("Inserisci l'orario: ");
			String orario=in.next();
			
			System.out.println("Inserisci il codice della struttura : ");
			String codiceStruttura=in.next();
			
			System.out.println("Inserisci il nome del centro : ");
			String nCentro=in.next();
			
			
			Statement query = con.createStatement();
	
			ResultSet result = query.executeQuery("SELECT OraP, DataP, CodiceStruttura, NomeCentro"
					+ " FROM prenotazione "
					+ " WHERE OraP= '"+orario+"' AND CodiceStruttura='"+codiceStruttura+"' AND NomeCentro='"+nCentro+"'"
					+ " GROUP BY OraP, DataP ");
		
			ArrayList<DataCompleta> dateListOutput = new ArrayList<DataCompleta>();
			
			while(result.next()){
				
				String ora = result.getString("OraP");
				
				String data = result.getString("DataP");
				
				String cStruttura = result.getString("CodiceStruttura");
				
				String nomeCentro = result.getString("NomeCentro");
				
				initDate();
				
				
				DataCompleta dataC = new DataCompleta();
				dataC.setData(data);
				dataC.setOra(ora.substring(0, 2));
				
				
				for (DataCompleta dc : dateList) {
					
					/*
					 * Abbiamo una lista di tutti i giorni e di tutte le ore; 
					 * scorrendo quella lista vado ad aggiungere in una lista d'appoggio dateListOutput tutti gli orari che hanno la stessa ora di quella inserita dall'utente e non lo stesso giorno, 
					 * quindi il giorno selezionato dall'utente viene escluso ; anche tutti gli altri giorni in quell'orario vengono esclusi da quella lista 
					 * per cui la lista di output avr� solo i giorni con l'orario scelto che fanno parte della lista presenete nell'init date.
					 * 
					 * Controllo se dc � uguale alla dataC e se dc � diversa dalla dataC
					 * se i due controlli saranno uguali aggiunge alla dateListOutput la dc 
					 * 
					 */
					if (dc.getOra().equals(dataC.getOra()) && (!dc.getData().equals(dataC.getData() ) )){
						
						dateListOutput.add(dc);
						
					}
				}
	
			}
			
			if (dateListOutput.isEmpty()) {
				//System.out.println("Il giorno selezionato e completamente disponibile");
				System.out.println("Query eseguita correttamente");
			}else {
				System.out.println("Elenco delle prenotazioni disponibili: ");
				for (DataCompleta dc : dateListOutput) {
					System.out.println("Data: " + dc.getData() + " Ora: " + dc.getOra());
				}
			}
		
			
		}
	
		catch (Exception e){
	
			System.out.println("Errore nell'interrogazione");
	}
	}
	
	/*
	 * QUERY 5
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * data: 2020-06-09
	 * orario: 9
	 * durata: 1
	 * codice struttura: 1
	 * nome centro: Olimpia
	 * codice attivita: 1
	 * 
	 */
	
	public static void Query5() {
		Connection con = null ;
		
		con=Connessione();
		
		Scanner in = new Scanner(System.in);
	
		try {
			
			System.out.println("Q5: Svolgimento di un�attivit�.\n");
			
			System.out.println("Inserisci la data : ");
			String data=in.next();
			
			/*
			 * Controllo sull'ora e sulla durata di un'attivita
			 */
			int orai;
			while(true) 
			{
				System.out.println("Inserisci l'ora (9-23): ");	
				orai = in.nextInt();
				
				if(9<=orai&&orai<=23)
					break;
			}
		
			String ora=""+orai+":00:00";
			
			int duratai;
			while(true) 
			{
				System.out.println("Inserisci durata: MAX (" +(24-orai)+"): ");
				duratai=in.nextInt();
				
				if(duratai<=(24-orai)) 
					break;
			}
			
			String durata=""+duratai+"";
			
			System.out.println("Inserisci il codice struttura : ");
			String codice=in.next();
			
			System.out.println("Inserisci il nome del centro: ");
			String nomeCentro=in.next();
			
			System.out.println("Inserisci il codice attivit� : ");
			String attivita=in.next();
			String que="INSERT INTO svolgimento"
			+ "(`DataS`, `OraS`, `Durata`,`CodiceStruttura`, `NomeCentro`, `CodiceAttivita`)"
			+ "VALUES(?,?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(que,Statement.RETURN_GENERATED_KEYS); 
			       
			        pstmt.setString(1, data);
			        pstmt.setString(2, ora);
			        pstmt.setString(3, durata);
			        pstmt.setString(4, codice);
			        pstmt.setString(5, nomeCentro);
			        pstmt.setString(6, attivita);
			        int affectedRows = pstmt.executeUpdate();
			        
			        System.out.println("L'attivit� � stata svolta correttamente!");
				
		}
		catch (Exception e){
			System.out.println(e);
			System.out.println("Errore nell'interrogazione");
		}
	}

	public static void Query6() {
		Connection con = null ;
		
		con=Connessione();
		
		Scanner in = new Scanner(System.in);
	
		try {
			
			System.out.println("Q6:  Visualizzazione per ogni attivit� del numero di ore in cui sono state svolte in un anno.  \n");
			
			
			Statement query = con.createStatement();
	
			ResultSet result = query.executeQuery("SELECT attivita.Denominazione, SUM(attivita.Durata) as Durata"
					+ " FROM attivita NATURAL JOIN svolgimento s"
					+ " WHERE s.DataS BETWEEN '2019-01-01' AND '2019-12-31'"
					+ " GROUP BY Denominazione");
	 	
			while(result.next()){
				
				String Denominazione = result.getString("Denominazione");
				
				String DurataTot = result.getString("Durata");
	
				System.out.println("Denominazione attivit�    :"+Denominazione +"\n"
								 + "Durata totale attivit�    :"+DurataTot+" ora/e \n");
	
			}
			
			System.out.println("Query eseguita correttamente");
		
		}
	
		catch (Exception e){
			
			System.out.println(e);
			System.out.println("Errore nell'interrogazione");
	}
	}
	
	/*
	 * QUERY 7
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * nome centro: BoxClub
	 * codice attivita: 1
	 * 
	 */
	
	public static void Query7() {
		Connection con = null ;
		
		con=Connessione();
		
		Scanner in = new Scanner(System.in);
			
		try {
			
			System.out.println("Q7: Abilitazione di un nuovo centro allo svolgimento di un�attivit�;  \n");
			
			System.out.println("Inserisci il nome centro : ");
			String nomecentro1=in.next();
			
			Statement query1 = con.createStatement();
			
			ResultSet result1 =query1.executeQuery("Select * from centro "
					+ "where Denominazione ='"+nomecentro1+"'");
			if(result1.next())System.out.println("Il centro esiste!\n");
			
			System.out.println("Inserisci il codice attivit� : ");
			String attivita = in.next();
			
			Statement query0 = con.createStatement();
			ResultSet result0 =query0.executeQuery("Select * from attivita "
					+ "where CodiceAttivita ='"+attivita+"' ");
			
			if(result0.next())System.out.println("L'attivita esiste!\n");
			//Statement query = con.createStatement();
		    //ResultSet rs;
			
		    String que="INSERT INTO riconosce VALUES(?,?)";
		    PreparedStatement pstmt = con.prepareStatement(que,Statement.RETURN_GENERATED_KEYS); 
		        
		        pstmt.setString(1, nomecentro1);
		        pstmt.setString(2, attivita);
		        int affectedRows = pstmt.executeUpdate();
		        
		        System.out.println("Centro abilitato");
		        System.out.println("Query eseguita correttamente");
		        
			}
		
		catch (SQLException ex) 
		{
				System.out.println(ex); 
			   System.out.println("Errore nell'esecuzione");
		}

	}

	/*
	 * QUERY 8
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * codice fiscale nuovo allenatore: FFDLMN00E45D123
	 * nome: Federico
	 * cognome: Mainardi
	 * recapito telefonico: 3313689745
	 * tipo contratto: Indeterminato
	 * anni esperienza: 2
	 * scelta specializzazione: 1
	 * specializzazione: Nuoto
	 * nessun documento
	 * 
	 */
	
	public static void Query8() {
		Connection con = null ;
		
		con=Connessione();
		
		Scanner in = new Scanner(System.in);	
			
		try {
			
			System.out.println("Q8: Assunzione di un nuovo allenatore.\n");
			
			int sc;
			
			System.out.println("Inserisci il codice fiscale : ");
			String codfis=in.next();
			Statement query0 = con.createStatement();
			ResultSet result0 =query0.executeQuery("Select * from istruttore "
					+ "where CodiceFiscale ='"+codfis+"'");
			if(result0.next()) throw new Exception("L'allenatore esiste quindi non � possibile assumere uno nuovo!\n");
			else System.out.println("L'allenatore non esiste quindi � possibile assumerlo!\n");
			
			System.out.println("Inserisci il nome  : ");
			String nome=in.next();
			System.out.println("Inserisci il cognome : ");
			String cognome=in.next();
			System.out.println("Inserisci il recapito telefonico : ");
			String tel=in.next();
			System.out.println("Inserisci il tipo contratto : ");
			String cont=in.next();
			System.out.println("Inserisci anni esperienza : ");
			String anni=in.next();
			System.out.println("L'istruttore ha una specializzazione? "
					+ "\n1)Si"
					+ "\n2)No"
					+ "\nScelta : ");
			sc = in.nextInt();
			String spec="";
			String doc="";
			if (sc==1) {
				System.out.println("Inserisci la specializzazione : ");
			    spec=in.next();
			    System.out.println("L'istruttore ha un documento che attesta la specializzazione? "
			    		+ "\n1)Si"
			    		+ "\n2)No"
			    		+ "\nScelta : ");
				sc = in.nextInt();
				if(sc==1) {
					System.out.println("Inserisci il nome del file del documento : ");
				    doc=in.next();
				}
			}
				String que="INSERT INTO istruttore VALUES(?,?,?,?,?,?,?,?)";
			    PreparedStatement pstmt = con.prepareStatement(que,Statement.RETURN_GENERATED_KEYS); 
			        
			        pstmt.setString(1, codfis);
			        pstmt.setString(2, nome);
			        pstmt.setString(3, cognome);
			        pstmt.setString(4, tel);
			        pstmt.setString(5, cont);
			        pstmt.setString(6, anni);
			        pstmt.setString(7, spec);
			        pstmt.setString(8, doc);
			        int affectedRows = pstmt.executeUpdate();
				
			        System.out.println("L'allenatore � stato assunto correttamente!");
			}
			
		catch (Exception e){
			System.out.println(e);
			System.out.println("Errore nell'interrogazione");
		}
	}

	public static void Query9() {
		Connection con = Connessione();
		
		try {
			
			System.out.println("Q9: Visualizzazione della struttura in cui sono state svolte il maggior numero di attivit� nell�anno corrente.\n");
			
			Statement query = con.createStatement();
			
			ResultSet result =query.executeQuery(
					"SELECT NomeCentro, CodiceStruttura " + 
					"FROM (SELECT NomeCentro, CodiceStruttura, COUNT(CodiceAttivita) AS NTot " + 
					"					FROM svolgimento " + 
					"					GROUP BY NomeCentro, CodiceStruttura ) AS NumeroTot " + 
					"WHERE NTot IN (SELECT MAX(NTot) " + 
					"					FROM (SELECT NomeCentro, CodiceStruttura, COUNT(CodiceAttivita) AS NTot " + 
					"					FROM svolgimento " + 
					"					GROUP BY NomeCentro, CodiceStruttura ) AS NumeroTot2);");
			while(result.next()) 
			 {
			
				System.out.println("Il Nome Centro      : "+result.getString("NomeCentro"));
			
				System.out.println("Il Codice Struttura : "+result.getString("CodiceStruttura"));
			}
			} 
		catch (Exception e) {
		        
			System.out.println("Errore nell'esecuzione");
		    }
	}
	
	/*
	 * QUERY 10
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * tipo specializzazione: Nuoto
	 * 
	 */
	
	public static void Query10() {
		Connection con = null ;
		
		con=Connessione();
		
		Scanner in = new Scanner(System.in);
		
		try {
			
			System.out.println("Query 10: Visualizzazione di tutti gli allenatori specializzati in una determinata disciplina.  \n");
			
			System.out.println("Inserisci la specializzazione ricercata: ");
			String tipoSpecializzazione = in.next();
			
			Statement query = con.createStatement();
	
			ResultSet result = query.executeQuery("select *"
					+ "from istruttore "
					+ "where Tipologia ='"+tipoSpecializzazione+"'");
		
			while(result.next()){
				
				String codiceFiscale = result.getString("CodiceFiscale");
				
				String nome = result.getString("Nome");
				
				String cognome = result.getString("Cognome");

				System.out.println("Codice Fiscale: "+codiceFiscale +"\nNome:"+nome+",\t Cognome:" +cognome+ "\t \n");
	 
			}
		
			System.out.println("Query eseguita correttamente");
			
		}
	
		catch (Exception e){
	
			System.out.println("Errore nell'interrogazione");
	}
	}

	/*
	 * QUERY 11
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * codice fiscale responsabile: CPSVCN04E09C127B
	 * nome centro: BoxClub
	 * codice fiscale nuovo responsabile: RRBNLS05S54C456S
	 * 
	 */
	
	public static void Query11() {
		Connection con = Connessione();
		
		Scanner in = new Scanner(System.in);
		
		try {
			
			System.out.println("Q11: Cancellazione di uno dei responsabili di un centro, con elezione di un nuovo responsabile. \n");
			
			System.out.println("Inserisci il codice fiscale del responsabile : ");
			String codfis=in.next();
			
			/*
			 * Controllo se il responsabile esiste all'interno del db
			 */
			Statement query0 = con.createStatement();
			ResultSet result0 =query0.executeQuery("Select * from responsabile "
					+ "where CodiceFiscale ='"+codfis+"'");
			if(result0.next())System.out.println("Il responsabile esiste \n");
			else throw new Exception("Il responsabile non esiste \n");
			
			/*
			 * Stampa la lista dei centri diretti dal responsabile
			 */
			Statement query1 = con.createStatement();
			ResultSet result1=query1.executeQuery("select * from dirige "
					+ "where Responsabile ='"+codfis+"'");
			
			System.out.println("Il responsabile : "+codfis+"\n"
					+ "Dirige i seguenti centri : ");
			
			while(result1.next()) {
				System.out.println(result1.getString("NomeCentro"));
			}
			
			System.out.println("Inserisci il nome del centro del quale non sar� pi� direttore : ");
			String nc=in.next();
			
			/*
			 * Eliminazione del responsabile dalla direzione del centro da noi scelto
			 */
			String query2 ="DELETE from dirige where Responsabile = ? and NomeCentro = ? ";
			PreparedStatement pstmt1 = con.prepareStatement(query2,Statement.RETURN_GENERATED_KEYS); 
		       
	        pstmt1.setString(1, codfis);
			pstmt1.setString(2, nc);
			int affected1Rows = pstmt1.executeUpdate();
			
			System.out.println("Codice fiscale del nuovo direttore : ");
			String codfis1=in.next();
			
			/*
			 * Controllo se il responsabile esiste all'interno del db
			 */
			Statement query3 = con.createStatement();
			ResultSet result3 =query3.executeQuery("Select * from responsabile "
					+ "where CodiceFiscale ='"+codfis1+"'");
			if(result3.next())System.out.println("Il responsabile esiste \n");
			else throw new Exception("Il responsabile non esiste \n");
			
			/*
			 * Nomino il nuovo responsabile che diriger� il centro da me scelto
			 */
			String que="INSERT INTO dirige VALUES(?,?)";
			PreparedStatement pstmt = con.prepareStatement(que,Statement.RETURN_GENERATED_KEYS); 
			       
			        pstmt.setString(1, codfis1);
					pstmt.setString(2, nc);
			        int affectedRows = pstmt.executeUpdate();
			
			System.out.println("Aggiornamento avvenuto con successo!");
			
		}
		
		catch (Exception e){
			System.out.println(e);
			System.out.println("Errore nell'interrogazione");
		}
	}
	
	/*
	 * QUERY 12
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * codice prenotazione: 5
	 * orario: 9
	 * 
	 */
	
	public static void Query12() {
		
		Scanner in = new Scanner(System.in);
		
		Connection con = Connessione();
		
		try {
			
			Statement query0 = con.createStatement();
			ResultSet result0 =query0.executeQuery("select * from prenotazione ");
			
			while(result0.next()) {
				
				System.out.println("Codice : "+result0.getString("CodicePrenotazione"));
				System.out.println("Data   : "+result0.getString("DataP"));
				System.out.println("Ora    : "+result0.getString("OraP"));
				System.out.println("Durata : "+result0.getString("Durata"));
				System.out.println("Descrizione : "+result0.getString("Descrizione"));
				System.out.println("Segretario  : "+result0.getString("Segretario"));
				System.out.println("Struttura   : "+result0.getString("CodiceStruttura"));
				System.out.println("Centro      : "+result0.getString("NomeCentro"));
				System.out.println("Attivita    : "+result0.getString("CodiceAttivita")+"\n\n");
				
			}
			
			System.out.println("Inserisci il codice della prenotazione che si desidera modificare :");
			int codpr=in.nextInt();
			 
			Statement query1 = con.createStatement();
			ResultSet result1 =query1.executeQuery("select * from prenotazione "
					+ "where COdicePrenotazione ='"+codpr+"'");
			result1.next();
			
			String data=result1.getString("DataP");
			String codice=result1.getString("CodiceStruttura");
			String nomecentro=result1.getString("NomeCentro");
			
			int duratai=result1.getInt("Durata");
			int orai;
			
			while(true) {
				
				System.out.println("Dammi l'ora (9 - 23): ");
				orai=in.nextInt();
			
				if(9<=orai&&orai<=23)break;
				
			}
			
			String ora=""+orai+":00:00";
			Statement query = con.createStatement();
			ResultSet result =query.executeQuery("select * from prenotazione "
					+ "where DataP ='"+data+"'"
					+ "and CodiceStruttura ='"+codice+"'"
					+ "and NomeCentro ='"+nomecentro+"'");
			
			while(result.next()) {
				
				Time orap = result.getTime("OraP");
				int orain=orap.getHours();
				int dur=result.getInt("Durata");
				if(orai<=orain && orain<(orai+duratai))	
					throw new Exception("La struttura non puo essere prenotata!");
				if(orain<=orai && orai<(orain+dur))	
					throw new Exception("La struttura non puo essere prenotata!");
				
			}
			
			String attivita=result1.getString("CodiceAttivita");
			Statement query2 = con.createStatement();
			ResultSet result2=query2.executeQuery("select Istruttore from presiede "
					+ "where CodiceAttivita ='"+attivita+"'");
			
			while(result2.next()) {
				
				String codicefiscale = result2.getString("Istruttore");
				Statement query3 = con.createStatement();
				ResultSet result3=query3.executeQuery("select CodiceAttivita from presiede "
						+ "where Istruttore ='"+codicefiscale+"'");
				while(result3.next()) {
					
					String codicecontrollo = result3.getString("CodiceAttivita");
					Statement query4 = con.createStatement();
					ResultSet result4=query4.executeQuery("select * from prenotazione "
							+ "where DataP ='"+data+"'"
							+ "and OraP ='"+ora+"'"
							+ "and CodiceAttivita ='"+codicecontrollo+"'");
					if(result4.next())throw new Exception("Impossibile effettuare la prenotazione "
							+ "dato che l'istruttore "+codicefiscale+" dell'attivita che si vuole "
									+ "prenotare � gi� impegnato in data "+data+" in ora "+ora);
					
				}
	
			}
			
			    String codprs=""+codpr;
				System.out.println("E' possibile effetture l'aggiornamento;\n"
						+ "Elaborazione in corso..");
				
				String que="UPDATE prenotazione SET OraP = ? WHERE CodicePrenotazione = ?";	
					PreparedStatement pstmt = con.prepareStatement(que,Statement.RETURN_GENERATED_KEYS); 
			        
			        pstmt.setString(1, ora);
			        pstmt.setString(2, codprs);
			        int affectedRows = pstmt.executeUpdate();
				
			    System.out.println("La prenotazione � stata modificata con successo!\n");
		}
			
		catch (Exception e){
			System.out.println(e);
			System.out.println("Errore nell'interrogazione");
		}
	}
	
	/*
	 * QUERY 13
	 * 
	 * Dati inseriti per il test della query:
	 * 
	 * codice attivit�: 11
	 * denominazione: Gara
	 * descrizione: test
	 * durata: 2
	 * periodicit�: 2
	 * scelta allenatore: 1
	 * scelta specializzazione: 1
	 * codice fiscale allenatore specializzato: DLANTN98A13H703Y
	 * scelta secondo allenatore: 2
	 * 
	 */
	
	public static void Query13() {
		Connection con = null ;
		
		con=Connessione();
		
		Scanner in = new Scanner(System.in);
		
		try {
			
			System.out.println("Q13: Caricamento di un corso organizzato da un centro, con l�assegnazione di eventuali allenatori. \n");

			System.out.println("Inserisci il codice : ");
			String cod=in.next();
			System.out.println("Inserisci la denominazione : ");
			String denominazione=in.next();
			System.out.println("Inserisci descrizione : ");
			String desc=in.next();
			System.out.println("Inserisci la durata in ore: ");
			String durata=in.next();
			System.out.println("Inserisci la periodicit� settimanale : ");
			String peri=in.next();
			String que="INSERT INTO attivita VALUES(?,?,?,?,?)";
			/*+ "(`Denominazione`, `Descrizione`, `Durata`,`Periodicita`)"
			*/
			PreparedStatement pstmt = con.prepareStatement(que,Statement.RETURN_GENERATED_KEYS); 
			       
			        pstmt.setString(1, cod);
					pstmt.setString(2, denominazione);
			        pstmt.setString(3, desc);
			        pstmt.setString(4, durata);
			        pstmt.setString(5, peri);
			        int affectedRows = pstmt.executeUpdate();
		   int sc;
		   int sc1;
		   do {
	       System.out.println("Assegnare un allenatore al corso? "); 
		   System.out.println("1)Si "
		   		+ "\n2)No");
		   sc= in.nextInt();
		   
		   switch(sc) {
		   	
		   case 1: 
		   		
			   System.out.println("L'allenatore da assegnare al corso deve essere specializzato? ");
		   	   System.out.println("1)Si "
		   				+ "\n2)No");
		   		sc1= in.nextInt();
		   		
		   		/*
		   		 * Controllo allenatori specializzati + inserimento di un allenatore specializzato in un determinato corso
		   		 * Gestione del vincolo: un allenatore specializzato pu� essere inserito direttamente da input nel corso che dovr� presiedere.
		   		 * Pi� allenatori possono essere legati ad un corso.
		   		 * 
		   		 */
		   		
		   		if(sc1==1) {
		   			
		   			System.out.println("Allenatori con specializzazione: ");
		   			
		   			Statement query0 = con.createStatement();
		   			
					ResultSet result0 = query0.executeQuery("select *"
							+ "from istruttore "
							+ "where Tipologia IS NOT NULL");	
					
					while(result0.next()){
						
						String codiceFiscale = result0.getString("CodiceFiscale");
						
						String nome = result0.getString("Nome");
						
						String cognome = result0.getString("Cognome");
						
						String tipoSpecializzazione = result0.getString("Tipologia");

						System.out.println("Codice Fiscale: "+codiceFiscale +"\nNome:"+nome+",\t Cognome:" +cognome+ ",\t Tipo Specializzazione:" +tipoSpecializzazione+ "\n");
			 
					}
					
					System.out.println("Inserisci il codice fiscale dell'allenatore specializzato che vuoi assegnare al corso: ");
			        String codfis=in.next();
			        
			        Statement query1 = con.createStatement();
			        
			        ResultSet result1 =query1.executeQuery("Select * from istruttore "
					        + "where CodiceFiscale ='"+codfis+"'");
			        
			        if(result1.next()) {
			        System.out.println("L'allenatore esiste");
			        
			        String que1="INSERT INTO presiede VALUES(?,?)";
			        			PreparedStatement pstmt1 = con.prepareStatement(que1,Statement.RETURN_GENERATED_KEYS); 
			        			       
			        			        pstmt1.setString(1, codfis);
			        			        pstmt1.setString(2, cod);
			        			        int affectedRows1 = pstmt1.executeUpdate();
			        			        
			        			        System.out.println("Inserimento allenatore avvenuto con successo! \n");    
		        }
					
		   	}
		   		else if(sc1==2){
		   			
		   			System.out.println("Allenatori senza specializzazione: ");
		   			
		   			Statement query2 = con.createStatement();
		   			
					ResultSet result2 = query2.executeQuery("select *"
							+ "from istruttore "
							+ "where Tipologia IS NULL");	
					
					while(result2.next()){
						
						String codiceFiscale = result2.getString("CodiceFiscale");
						
						String nome = result2.getString("Nome");
						
						String cognome = result2.getString("Cognome");

						System.out.println("Codice Fiscale: "+codiceFiscale +"\nNome:"+nome+",\t Cognome:" +cognome+ "\t \n");
					
					}
			   		
		   			System.out.println("Inserisci il codice fiscale dell'allenatore che vuoi assegnare al corso: ");
			        String codfis=in.next();
			        
			        Statement query3 = con.createStatement();
			        ResultSet result3 =query3.executeQuery("Select * from istruttore "
					        + "where CodiceFiscale ='"+codfis+"'");
			        if(result2.next()) {
			        System.out.println("L' allenatore esiste! \n");
			        String que1="INSERT INTO presiede VALUES(?,?)";
			        			PreparedStatement pstmt1 = con.prepareStatement(que1,Statement.RETURN_GENERATED_KEYS); 
			        			       
			        			        pstmt1.setString(1, codfis);
			        			        pstmt1.setString(2, cod);
			        			        int affectedRows1 = pstmt1.executeUpdate();
		        }
		        
		   	}
		        
		   		else throw new Exception("L'allenatore non esiste! \n");
		       
		   		break;
		   		
	       default : //System.out.println("Scelta errata");
	       
		   }
		   }while(sc!=2);
		   
		   System.out.println("Attivit� inserita con successo!");
		   
		}
		catch (Exception e){
			System.out.println(e);
			System.out.println("Errore nell'interrogazione");
		}
	}
	
	public static void Query14() {
		Connection con = Connessione();
		
		/*
		 * La seguente query stamper� tutti i dati delle strutture che sono state prenotate durante l'anno preso in considerazione
		 * Periodo dell'anno preso in considerazione: dal 2019-01-01 al 2019-12-31
		 * 
		 */
		
		try {
			
			System.out.println("Q14: Stampa annuale di un report che mostri i dati delle strutture, incluso il numero totale di giorni in cui � stata libera.\n");
			
			Statement query = con.createStatement();
			
			ResultSet result =query.executeQuery(
					"SELECT CodiceStruttura, AreaOccupata, NomeCentro, 360-COUNT(DISTINCT DataP) AS GiorniLiberi "
					+ "FROM struttura NATURAL JOIN prenotazione "
					+ "WHERE DataP BETWEEN '2019-01-01' AND '2019-12-31' "
					+ "GROUP BY CodiceStruttura, NomeCentro");
			
			System.out.println("Le strutture che non verranno stampate indicano che non sono mai state utilizzate durante l'anno \n");
			
			while(result.next()) 
			 {
			
				System.out.println("Il codice della struttura      : "+result.getString("CodiceStruttura"));
			
				System.out.println("L'area occupata �              : "+result.getString("AreaOccupata"));
				
				System.out.println("Il Nome Centro                 : "+result.getString("NomeCentro"));
				
				System.out.println("I giorni liberi                :  "+result.getString("GiorniLiberi")+" \n");
			}
			} 
		catch (Exception e) {
		        
			System.out.println("Errore nell'esecuzione");
		    }
	}
	
	public static void Query15() {
		Connection con = Connessione();
		
		/*
		 * La seguente query stamper� tutti i dati delle strutture che sono state occupate in termini di ore durante l'anno
		 * Periodo dell'anno preso in considerazione: dal 2019-01-01 al 2021-12-31
		 * 
		 */
		
		try {
			
			System.out.println("Q15: Stampa annuale di un report che mostri i dati delle strutture, incluso il numero di ore in cui sono state occupate negli ultimi due anni.\n");
			
			Statement query = con.createStatement();
			
			ResultSet result =query.executeQuery(
					"SELECT CodiceStruttura, AreaOccupata, NomeCentro, SUM(Durata) AS OreOccupate "
					+ "FROM struttura NATURAL JOIN prenotazione "
					+ "WHERE DataP BETWEEN '2019-01-01' AND '2021-12-31' "
					+ "GROUP BY CodiceStruttura, NomeCentro");
			
			System.out.println("Le strutture che non verranno stampate indicano che non sono mai state occupate durante l'anno \n");
			
			while(result.next()) 
			 {
			
				System.out.println("Il codice della struttura      : "+result.getString("CodiceStruttura"));
			
				System.out.println("L'area occupata �              : "+result.getString("AreaOccupata"));
				
				System.out.println("Il Nome Centro                 : "+result.getString("NomeCentro"));
				
				System.out.println("Numero di ore occupate         :  "+result.getString("OreOccupate")+" ore \n");
				
			}
			} 
		catch (Exception e) {
		        
			System.out.println("Errore nell'esecuzione");
			
		    }
	}
	
}

