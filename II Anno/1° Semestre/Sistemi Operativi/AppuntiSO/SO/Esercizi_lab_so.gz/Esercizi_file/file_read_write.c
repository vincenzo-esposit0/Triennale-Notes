#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#define BUFFSIZE 8192

int main(void){


	int fr;
	int fw;
	char buf[BUFFSIZE]={0};	
	int n;

	fr=open("prova_read_write.txt", O_RDONLY);
	if(fr<0){

		perror("open");	
		exit(0);
	}

	fw=creat("prova_read_write_out.txt",0644);


	while((n=read(fr,buf,BUFFSIZE))>0){
		
			write(fw,buf,n);		
	}

	if(n<0){
		printf("Errore read\n");
		exit(0);
	}

	close(fr);
	close(fw);
	
}