#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#define BUFFSIZE 1


int main(int argc, char *argv[]){


	
	int f1, f2;
	int n;
	char c[250]={0};
	char lower;
	char upper;
	
	f1=open(argv[1], O_RDONLY);

	if(f1==-1){
		perror("open");
	}

	f2=open(argv[2], O_WRONLY|O_CREAT);
	

	while((n=read(f1,c,BUFFSIZE))>0){

			if(isupper(c[0])){

				lower= tolower(c[0]);
				write(f2,&lower,n);
				

			}

	}



}