#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>

int main(void){
		
	int fd;
	fd=open("prova.txt", O_RDONLY);

	if(fd==-1){
		printf("Errore");
		exit(-1);
	}
	printf("%d", fd);
}

