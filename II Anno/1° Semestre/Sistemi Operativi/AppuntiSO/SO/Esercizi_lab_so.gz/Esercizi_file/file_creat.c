#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>

int main(void){
		
	int fd;
	fd=creat("prova_creat.txt", S_IRUSR | S_IWUSR | S_IXUSR);
	if(fd==-1){
		perror("Creat");
		exit(-1);
	} 

	printf("%d", fd);
	
}
