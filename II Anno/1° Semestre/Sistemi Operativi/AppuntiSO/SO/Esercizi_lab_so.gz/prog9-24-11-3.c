#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>



int fib(int n)	{

	if(n<=1){
		return n;
	}
	else {
		return (fib(n-1) + fib(n-2));
	}

}

void handler_ctrl_c(int signo){
	
		signal(SIGINT, SIG_IGN);
		pid_p pid2;
		pid2=fork();
		
		if(pid2<=0{
				printf("errore pid2");
				exit(-1);
		}
		
		else if(pid2==0){
			printf("ricevuto segnale interruzione\n\n %d", signo);
			char riposta[280]={0};
			printf("Vuoi continuare(c) o terminare(f)?");
			scanf("s", risposta);
			if(*risposta==c){
					exit(0);
			}
			else{
					
					kill(getppid(), SIGINT);
					raise(SIGKILL);
			}

			
			
		}
		else{
				wait(NULL);
				signal(SIGINT, handler_ctrl_c);
		}
		

}


int main(void){
		
		pid_t pidf;
		
		pidf=fork();
		
		
		if(pidf<0){
			
			printf("errore");
			exit(-1);
		}
		
		else if(pidf==0){
			
			int i=0;
			signal(SIGINT, handler_ctrl_c);
			for(i=0;i<45;i++){
					printf("fib(%2d) =%d\n", i, fib(i));
			}
			
		}
		
		else{
			
			signal(SIGINT,SIG_IGN);
			wait(NULL);
			printf("Padre: figlio termintato. Ilsuo pid era questo", pid);
			
		}
	
	
	
}
