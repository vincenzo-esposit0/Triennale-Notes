#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


void handler(){
printf("Ciao\n");
}

void sleep2(int number){
	
	
	if(signal(SIGALRM, handler) == SIG_ERR){
		
		printf("Errore di sistema: SIGALRM \n\n");
		exit(-1);
		
	}
	
	alarm(number);
	
}



int main(void){
	printf("Sleep per 2 secondi\n\n");
	sleep2(2);
	printf("Sleep per 1 secondo\n\n");
	sleep2(1);
	printf("Sleep per 4 secondi\n\n");
	sleep2(4);
	
}
