#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


void sig_usr(int signo){
		
		if(signo==SIGUSR1){
				printf("Ricevuto SIGUSR1 \n\n"); 
		}
		else{
				printf("Ricevuto SIGUSR2 \n\n");
		}
}


int main(void){
	
	
	if(signal(SIGUSR1, sig_usr)==SIG_ERR){
			printf("Errore SIGUSR1");
			exit(0);
	}
	if(signal(SIGUSR2, sig_usr)==SIG_ERR){
			printf("Errore SIGUSR2");
			exit(0);
	}
	
	while(pause()==-1) {
	
	}
	
	
	
}
