package model.indirizzo;

import java.sql.SQLException;
import java.util.Collection;

import model.indirizzo.IndirizzoBean;

public interface IndirizzoDAO {
	
	public void doSave(IndirizzoBean indirizzo) throws SQLException;
	
	public Collection<IndirizzoBean> getIndirizzoByIdUser (int idUser) throws SQLException;
	
	public IndirizzoBean doRetriveByKey(int code) throws SQLException;
	
	public boolean doDelete(int code) throws SQLException;

}
