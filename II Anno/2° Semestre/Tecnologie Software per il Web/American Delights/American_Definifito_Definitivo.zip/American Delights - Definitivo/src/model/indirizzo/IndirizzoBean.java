package model.indirizzo;

import java.util.Collection;

public class IndirizzoBean {
	
	public IndirizzoBean() {
		this.id = -1;
	}
	public String getVia() {
		return via;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public void setVia(String via) {
		this.via = via;
	}

	public String getNCivico() {
		return nCivico;
	}

	public void setNCivico(String nCivico) {
		this.nCivico = nCivico;
	}

	public String getCitta() {
		return citta;
	}

	public void setCitta(String citta) {
		this.citta = citta;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getCap() {
		return cap;
	}
	
	public void setCap(String cap) {
	this.cap = cap;
	}
		
	public String getDescrizione() {
	return descrizione;
	}

	public void setDescrizione(String descrizione) {
	this.descrizione = descrizione;
	}

	public int getIdUtente() {
	return idUtente;
	}
		
	public void setIdUtente(int idUtente) {
	this.idUtente = idUtente;
	}
	
	private String via, nCivico, citta, provincia, cap, descrizione;
	private int id, idUtente;
	
}
