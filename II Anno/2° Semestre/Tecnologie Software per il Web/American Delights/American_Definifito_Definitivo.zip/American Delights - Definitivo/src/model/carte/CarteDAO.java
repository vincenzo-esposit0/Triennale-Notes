package model.carte;

import java.sql.SQLException;

public interface CarteDAO {
	
	/**
	 * Ritorna se una carta � esistente
	 * @param nCarta
	 * @return true se una carta esiste, false altrimenti
	 * @throws SQLException
	 */
	boolean cartaEsistente(String nCarta) throws SQLException;
	
	boolean pagamentoPossibile(String nCarta, float spesa) throws SQLException;
	
	/**
	 * Effettua un pagamento
	 * @param nCarta
	 * @param spesa
	 * @throws SQLException
	 */
	void effettuaPagamento(String nCarta, float spesa) throws SQLException;

}
