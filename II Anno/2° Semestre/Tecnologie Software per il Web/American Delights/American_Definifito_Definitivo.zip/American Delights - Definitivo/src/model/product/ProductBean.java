package model.product;

import java.util.Collection;

import model.image.ImageBean;

public class ProductBean {

	public ProductBean() {
		this.id = -1;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getFormato() {
		return formato;
	}

	public void setFormato(String formato) {
		this.formato = formato;
	}

	public String getIngredienti() {
		return ingredienti;
	}

	public void setIngredienti(String ingredienti) {
		this.ingredienti = ingredienti;
	}

	public String getInfoAllergeni() {
		return infoAllergeni;
	}

	public void setInfoAllergeni(String infoAllergeni) {
		this.infoAllergeni = infoAllergeni;
	}

	public String getValoriNutrizionali() {
		return valoriNutrizionali;
	}

	public void setValoriNutrizionali(String valoriNutrizionali) {
		this.valoriNutrizionali = valoriNutrizionali;
	}

	public float getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(float prezzo) {
		this.prezzo = prezzo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSconto() {
		return sconto;
	}

	public void setSconto(int sconto) {
		this.sconto = sconto;
	}

	public int getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public boolean isGlutine() {
		return glutine;
	}

	public void setGlutine(boolean glutine) {
		this.glutine = glutine;
	}
	
	public int getQuantita() {
		return quantita;
	}

	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}
	
	public int getQuantitaV() {
		return quantitav;
	}

	public void setQuantitaV(int quantitav) {
		this.quantitav = quantitav;
	}
	
	public Collection<ImageBean> getImmagini() {
		return immagini;
	}

	public void setImmagini(Collection<ImageBean> immagini) {
		this.immagini = immagini;
	}

	private String nome, formato, ingredienti, infoAllergeni, valoriNutrizionali;
	
	private float prezzo;
	
	private int id, sconto, idCategoria, quantita, quantitav;
	
	private boolean glutine;
	
	private Collection<ImageBean> immagini;
	
	public static final int IVA = 10; //E' una percentuale
	
}
