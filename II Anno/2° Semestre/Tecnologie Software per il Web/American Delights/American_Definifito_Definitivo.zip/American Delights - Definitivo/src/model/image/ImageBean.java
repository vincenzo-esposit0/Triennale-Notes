package model.image;

public class ImageBean {

	public ImageBean() {
		this.id = -1;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getIdProdotto() {
		return idProdotto;
	}
	public void setIdProdotto(int idProdotto) {
		this.idProdotto = idProdotto;
	}
	public boolean isPredefinito() {
		return predefinito;
	}
	public void setPredefinito(boolean predefinito) {
		this.predefinito = predefinito;
	}
	public String getPathname() {
		return pathname;
	}
	public void setPathname(String pathname) {
		this.pathname = pathname;
	}

	private int id, idProdotto;
	private boolean predefinito;
	private String pathname;
}
