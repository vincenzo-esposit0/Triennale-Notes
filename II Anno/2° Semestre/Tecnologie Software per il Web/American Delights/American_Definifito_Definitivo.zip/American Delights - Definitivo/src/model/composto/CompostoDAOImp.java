package model.composto;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class CompostoDAOImp implements CompostoDAO{

	public CompostoDAOImp() {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/american");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	
	@Override
	public void doSave(CompostoBean composto) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO " + CompostoDAOImp.TABLE_NAME
				+ " (idOrdine, idProdotto, quantita, prezzo, iva, sconto)"
				+ " VALUES (?, ?, ?, ?, ?, ?)";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setInt(1, composto.getIdOrdine());
			preparedStatement.setInt(2, composto.getIdProdotto());
			preparedStatement.setInt(3, composto.getQuantita());
			preparedStatement.setFloat(4, composto.getPrezzo());
			preparedStatement.setFloat(5, composto.getIva());
			preparedStatement.setFloat(6, composto.getSconto());

			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
	}

	@Override
	public Collection<CompostoBean> doRetrieveByOrderKey(int idOrdine) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<CompostoBean> composti = new LinkedList<CompostoBean>();

		String selectSQL = "SELECT * FROM " + CompostoDAOImp.TABLE_NAME + " WHERE idOrdine = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1,idOrdine);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				CompostoBean bean = new CompostoBean();
				bean.setIdOrdine( rs.getInt("idOrdine") );
				bean.setIdProdotto( rs.getInt("idProdotto") );
				bean.setQuantita( rs.getInt("quantita") );
				bean.setPrezzo( rs.getFloat("prezzo") );
				bean.setIva( rs.getFloat("iva") );
				bean.setSconto( rs.getFloat("sconto") );
				composti.add( bean );
			}
			
		}
		catch(SQLException e) {
			return null;
		}
		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return composti;
	}
	
	private static final String TABLE_NAME = "composto";
	
	private DataSource ds;

}

