package model.product;

import java.sql.SQLException;
import java.util.Collection;

public interface ProductDAO {
	
	public void doSave(ProductBean product) throws SQLException;

	public boolean doDelete(int id) throws SQLException;

	public ProductBean doRetrieveByKey(int id) throws SQLException;
	
	/**
	 * Ricerca dei prodotti in base all'id di categoria
	 * @param filter
	 * @return
	 * @throws SQLException
	 */
	public Collection<ProductBean> getProductByIdCategory(int idCategory) throws SQLException;
	
	public Collection<ProductBean> doRetrieveAll(String order) throws SQLException;
	
	public Collection<ProductBean> doRetrieveMostOrder() throws SQLException;
	
	public void updateQuantita(int idOrdine, int quantita) throws SQLException;
	
	public Collection<ProductBean> doRetriveGlutine(boolean tipo) throws SQLException;
	
	public Collection<ProductBean> doRetriveOfferte() throws SQLException;
	
	public void doUpdate(ProductBean product) throws SQLException;

}
