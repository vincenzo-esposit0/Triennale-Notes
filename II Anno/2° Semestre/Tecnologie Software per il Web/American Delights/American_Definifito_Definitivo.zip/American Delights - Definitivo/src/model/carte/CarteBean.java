package model.carte;

public class CarteBean {
	
	public CarteBean() {
		this.id = -1;
	}
	
	public String getnCarta() {
		return nCarta;
	}

	public void setnCarta(String nCarta) {
		this.nCarta = nCarta;
	}

	public float getSaldo() {
		return saldo;
	}

	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}

	private float saldo;
	private String nCarta;
	private int id;
}
