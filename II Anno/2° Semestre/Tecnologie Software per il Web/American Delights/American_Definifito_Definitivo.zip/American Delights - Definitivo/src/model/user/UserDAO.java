package model.user;

import java.sql.SQLException;
import java.util.Collection;

public interface UserDAO {

	public void doSave(UserBean user) throws SQLException;
	
	/**
	 * Controlla se esiste un utente con una determinata email
	 * @param email
	 * @return true se esiste gi� un utente con una determinata email, false altrimenti
	 * @throws SQLException
	 */
	public boolean isEmail(String email) throws SQLException;

	public UserBean doRetrieveByKey(String email, String password) throws SQLException;
	
	public Collection<UserBean> doRetrieveAll() throws SQLException;
}
