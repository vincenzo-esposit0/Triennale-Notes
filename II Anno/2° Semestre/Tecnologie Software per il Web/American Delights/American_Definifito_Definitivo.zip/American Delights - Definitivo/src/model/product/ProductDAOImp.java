package model.product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import model.product.ProductBean;

public class ProductDAOImp implements ProductDAO {

	public ProductDAOImp() {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/american");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}

	@Override
	public synchronized void doSave(ProductBean product) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO " + ProductDAOImp.TABLE_NAME
				+ " (nome, formato, ingredienti, infoAllergeni, valoriNutrizionali, prezzo, sconto, glutine, idCategoria, quantita)"
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, product.getNome());
			preparedStatement.setString(2, product.getFormato());
			preparedStatement.setString(3, product.getIngredienti());
			preparedStatement.setString(4, product.getInfoAllergeni());
			preparedStatement.setString(5, product.getValoriNutrizionali());
			preparedStatement.setFloat(6, product.getPrezzo());
			preparedStatement.setInt(7, product.getSconto());
			preparedStatement.setBoolean(8, product.isGlutine());
			preparedStatement.setInt(9, product.getIdCategoria());
			preparedStatement.setInt(10, product.getQuantita());

			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}

	@Override
	public synchronized ProductBean doRetrieveByKey(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ProductBean bean = new ProductBean();

		String selectSQL = "SELECT * FROM " + ProductDAOImp.TABLE_NAME + " WHERE idProdotto = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, code);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				bean.setId(rs.getInt("idProdotto"));
				bean.setNome(rs.getString("nome"));
				bean.setFormato(rs.getString("formato"));
				bean.setIngredienti(rs.getString("ingredienti"));
				bean.setInfoAllergeni(rs.getString("infoAllergeni"));
				bean.setValoriNutrizionali(rs.getString("valoriNutrizionali"));
				bean.setPrezzo(rs.getFloat("prezzo"));
				bean.setSconto(rs.getInt("sconto"));
				bean.setGlutine(rs.getBoolean("glutine"));
				bean.setIdCategoria(rs.getInt("idCategoria"));
				bean.setQuantita(rs.getInt("quantita"));
				
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}

	@Override
	public synchronized boolean doDelete(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result = 0;

		String updateSQL = "UPDATE "+ ProductDAOImp.TABLE_NAME +" SET quantita=-1 WHERE idProdotto=?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(updateSQL);
			preparedStatement.setInt(1,code);

			result = preparedStatement.executeUpdate();
			connection.commit();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}

	@Override
	public synchronized Collection<ProductBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<ProductBean> products = new LinkedList<ProductBean>();

		String selectSQL = "SELECT * FROM " + ProductDAOImp.TABLE_NAME;

		if (order != null && !order.equals("")) {
			selectSQL += " ORDER BY " + order;
		}

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();
				bean.setId(rs.getInt("idProdotto"));
				bean.setNome(rs.getString("nome"));
				bean.setFormato(rs.getString("formato"));
				bean.setIngredienti(rs.getString("ingredienti"));
				bean.setInfoAllergeni(rs.getString("infoAllergeni"));
				bean.setValoriNutrizionali(rs.getString("valoriNutrizionali"));
				bean.setPrezzo(rs.getFloat("prezzo"));
				bean.setSconto(rs.getInt("sconto"));
				bean.setGlutine(rs.getBoolean("glutine"));
				bean.setIdCategoria(rs.getInt("idCategoria"));
				bean.setQuantita(rs.getInt("quantita"));
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}
	
	public Collection<ProductBean> getProductByIdCategory(int idCategory) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<ProductBean> products = new LinkedList<ProductBean>();

		String selectSQL = "SELECT * FROM "+ProductDAOImp.TABLE_NAME+" WHERE idCategoria=?";
		
		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, idCategory);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();
				bean.setId(rs.getInt("idProdotto"));
				bean.setNome(rs.getString("nome"));
				bean.setFormato(rs.getString("formato"));
				bean.setIngredienti(rs.getString("ingredienti"));
				bean.setInfoAllergeni(rs.getString("infoAllergeni"));
				bean.setValoriNutrizionali(rs.getString("valoriNutrizionali"));
				bean.setPrezzo(rs.getFloat("prezzo"));
				bean.setSconto(rs.getInt("sconto"));
				bean.setGlutine(rs.getBoolean("glutine"));
				bean.setIdCategoria(rs.getInt("idCategoria"));
				bean.setQuantita(rs.getInt("quantita"));
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
		
	}
	
	public synchronized Collection<ProductBean> doRetrieveMostOrder() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<ProductBean> products = new LinkedList<ProductBean>();

		String selectSQL = "select prodotto.idProdotto,prodotto.nome,prodotto.formato,prodotto.quantita As Quantita_esistente,sum(composto.quantita) As Quantita_Venduta "
				+ "from prodotto,composto "
				+ "where prodotto.idProdotto = composto.idProdotto "
				+ "group by prodotto.idProdotto "
				+ "order by Quantita_Venduta desc";

		

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();
				bean.setId(rs.getInt("prodotto.idProdotto"));
				bean.setNome(rs.getString("prodotto.nome"));
				bean.setFormato(rs.getString("prodotto.formato"));
				bean.setQuantita(rs.getInt("Quantita_Esistente"));
				bean.setQuantitaV(rs.getInt("Quantita_Venduta"));
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}
	
	public void updateQuantita(int idProdotto,int quantita) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "UPDATE " + ProductDAOImp.TABLE_NAME
		    + " SET "
		    + "quantita=quantita-? "
		    + "WHERE idProdotto=?";

		try {
		  connection = ds.getConnection();
		  preparedStatement = connection.prepareStatement(insertSQL);
		  preparedStatement.setInt(1, quantita);
		  preparedStatement.setInt(2, idProdotto);

		  preparedStatement.executeUpdate();

		  connection.commit();
		} finally {
		  try {
		    if (preparedStatement != null)
		      preparedStatement.close();
		  } finally {
		    if (connection != null)
		      connection.close();
		  }
		}
	}
	
	@Override
	public Collection<ProductBean> doRetriveGlutine(boolean tipo) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<ProductBean> products = new LinkedList<ProductBean>();

		String selectSQL = "SELECT * FROM " + ProductDAOImp.TABLE_NAME +" WHERE glutine = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setBoolean(1, tipo);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();
				bean.setId(rs.getInt("idProdotto"));
				bean.setNome(rs.getString("nome"));
				bean.setFormato(rs.getString("formato"));
				bean.setIngredienti(rs.getString("ingredienti"));
				bean.setInfoAllergeni(rs.getString("infoAllergeni"));
				bean.setValoriNutrizionali(rs.getString("valoriNutrizionali"));
				bean.setPrezzo(rs.getFloat("prezzo"));
				bean.setSconto(rs.getInt("sconto"));
				bean.setGlutine(rs.getBoolean("glutine"));
				bean.setIdCategoria(rs.getInt("idCategoria"));
				bean.setQuantita(rs.getInt("quantita"));
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	@Override
	public Collection<ProductBean> doRetriveOfferte() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<ProductBean> products = new LinkedList<ProductBean>();

		String selectSQL = "SELECT * FROM " + ProductDAOImp.TABLE_NAME +" WHERE sconto>0 ";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();
				bean.setId(rs.getInt("idProdotto"));
				bean.setNome(rs.getString("nome"));
				bean.setFormato(rs.getString("formato"));
				bean.setIngredienti(rs.getString("ingredienti"));
				bean.setInfoAllergeni(rs.getString("infoAllergeni"));
				bean.setValoriNutrizionali(rs.getString("valoriNutrizionali"));
				bean.setPrezzo(rs.getFloat("prezzo"));
				bean.setSconto(rs.getInt("sconto"));
				bean.setGlutine(rs.getBoolean("glutine"));
				bean.setIdCategoria(rs.getInt("idCategoria"));
				bean.setQuantita(rs.getInt("quantita"));
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}
	
	@Override
	public synchronized void doUpdate(ProductBean product) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "UPDATE " + ProductDAOImp.TABLE_NAME
				+ " SET "
				+ "nome=?, "
				+ "formato=?, "
				+ "ingredienti=?, "
				+ "infoAllergeni=?, "
				+ "valoriNutrizionali=?, "
				+ "prezzo=?, "
				+ "sconto=?, "
				+ "glutine=?, "
				+ "idCategoria=?, "
				+ "quantita=? "
				+ "WHERE idProdotto=?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, product.getNome());
			preparedStatement.setString(2, product.getFormato());
			preparedStatement.setString(3, product.getIngredienti());
			preparedStatement.setString(4, product.getInfoAllergeni());
			preparedStatement.setString(5, product.getValoriNutrizionali());
			preparedStatement.setFloat(6, product.getPrezzo());
			preparedStatement.setInt(7, product.getSconto());
			preparedStatement.setBoolean(8, product.isGlutine());
			preparedStatement.setInt(9, product.getIdCategoria());
			preparedStatement.setInt(10, product.getQuantita());
			preparedStatement.setInt(11, product.getId());

			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}
	
	private static final String TABLE_NAME = "prodotto";
	
	private DataSource ds;

	
}
