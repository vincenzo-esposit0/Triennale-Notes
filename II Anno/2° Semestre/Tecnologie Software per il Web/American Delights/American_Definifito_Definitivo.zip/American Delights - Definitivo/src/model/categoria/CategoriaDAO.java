package model.categoria;

import java.sql.SQLException;
import java.util.Collection;

public interface CategoriaDAO {

	public void doSave(CategoriaBean product) throws SQLException;

	public boolean doDelete(int id) throws SQLException;

	public CategoriaBean doRetrieveByKey(int id) throws SQLException;
	
	public Collection<CategoriaBean> doRetrieveAll(String order) throws SQLException;
}
