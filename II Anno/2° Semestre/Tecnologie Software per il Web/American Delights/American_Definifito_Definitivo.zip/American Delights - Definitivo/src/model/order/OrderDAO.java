package model.order;

import java.sql.SQLException;
import java.util.Collection;

public interface OrderDAO {

	public void doSave(OrderBean order) throws SQLException;

	/**
	 * Restituisce un ordine in base all'id
	 * @param idOrdine
	 * @return order
	 * @throws SQLException
	 */
	public OrderBean doRetrieveSingleOrder(int idOrdine) throws SQLException;

	/**
	 * Restituisce tutti gli ordini di un utente
	 * @param idUtente
	 * @return
	 * @throws SQLException
	 */
	public Collection<OrderBean> doRetrieveAll(int idUtente) throws SQLException;

	/**
	 * Restituisce tutti gli ordini presenti del db
	 * @return
	 * @throws SQLException
	 */
	public Collection<OrderBean> doRetrieveAll() throws SQLException;
	
	/**
	 * Ritorna l'id dell'ultimo ordine effettuato, altrimenti ritorna -1
	 * @return idOrdine oppure -1 ( Nel caso in cui non ci siano ordini )
	 * @throws SQLException
	 */
	public int idLastOrder() throws SQLException;

}
