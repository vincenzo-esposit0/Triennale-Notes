package model.order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import model.product.ProductBean;

public class OrderDAOImp implements OrderDAO {

	public OrderDAOImp() {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/american");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}

	@Override
	public synchronized void doSave(OrderBean order) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO " + OrderDAOImp.TABLE_NAME
				+ " (dataOrdine, descrizione, idUtente, via, nCivico, citta, provincia, cap, stato, nome, cognome, email, quantita, prezzoTot)"
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setDate(1, order.getDataOrdine());
			preparedStatement.setString(2, order.getDescrizione());
			preparedStatement.setInt(3, order.getIdUtente());
			preparedStatement.setString(4, order.getVia());
			preparedStatement.setString(5, order.getnCivico());
			preparedStatement.setString(6, order.getCitta());
			preparedStatement.setString(7, order.getProvincia());
			preparedStatement.setString(8, order.getCap());
			preparedStatement.setString(9, order.getStato());
			preparedStatement.setString(10, order.getNome());
			preparedStatement.setString(11, order.getCognome());
			preparedStatement.setString(12, order.getEmail());
			preparedStatement.setInt(13, order.getQuantita());
			preparedStatement.setFloat(14, order.getPrezzoTot());


			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}

	@Override
	public synchronized OrderBean doRetrieveSingleOrder(int idOrdine) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		OrderBean bean = new OrderBean();

		String selectSQL = "SELECT * FROM " + OrderDAOImp.TABLE_NAME + " WHERE idOrdine = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, idOrdine);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				bean.setIdOrdine(rs.getInt("idOrdine"));
				bean.setDataOrdine(rs.getDate("dataOrdine"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setIdUtente(rs.getInt("idUtente"));
				bean.setVia(rs.getString("via"));
				bean.setnCivico(rs.getString("nCivico"));
				bean.setCitta(rs.getString("citta"));
				bean.setProvincia(rs.getString("provincia"));
				bean.setCap(rs.getString("cap"));
				bean.setStato(rs.getString("stato"));
				bean.setNome(rs.getString("nome"));
				bean.setCognome(rs.getString("cognome"));
				bean.setEmail(rs.getString("email"));
				bean.setQuantita(rs.getInt("quantita"));
				bean.setPrezzoTot(rs.getFloat("prezzoTot"));

			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}
	
	@Override
	public synchronized Collection<OrderBean> doRetrieveAll(int idUtente) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<OrderBean> user_orders = new LinkedList<OrderBean>();

		String selectSQL = "SELECT * FROM " + OrderDAOImp.TABLE_NAME + " WHERE idUtente = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, idUtente);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				OrderBean bean = new OrderBean();

				bean.setIdOrdine(rs.getInt("idOrdine"));
				bean.setDataOrdine(rs.getDate("dataOrdine"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setIdUtente(rs.getInt("idUtente"));
				bean.setVia(rs.getString("via"));
				bean.setnCivico(rs.getString("nCivico"));
				bean.setCitta(rs.getString("citta"));
				bean.setProvincia(rs.getString("provincia"));
				bean.setCap(rs.getString("cap"));
				bean.setStato(rs.getString("stato"));
				bean.setNome(rs.getString("nome"));
				bean.setCognome(rs.getString("cognome"));
				bean.setEmail(rs.getString("email"));
				bean.setQuantita(rs.getInt("quantita"));
				bean.setPrezzoTot(rs.getFloat("prezzoTot"));

				user_orders.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return user_orders;
	}

	@Override
	public Collection<OrderBean> doRetrieveAll() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<OrderBean> all_orders = new LinkedList<OrderBean>();

		String selectSQL = "SELECT * FROM " + OrderDAOImp.TABLE_NAME;

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				OrderBean bean = new OrderBean();

				bean.setIdOrdine(rs.getInt("idOrdine"));
				bean.setDataOrdine(rs.getDate("dataOrdine"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setIdUtente(rs.getInt("idUtente"));
				bean.setVia(rs.getString("via"));
				bean.setnCivico(rs.getString("nCivico"));
				bean.setCitta(rs.getString("citta"));
				bean.setProvincia(rs.getString("provincia"));
				bean.setCap(rs.getString("cap"));
				bean.setStato(rs.getString("stato"));
				bean.setNome(rs.getString("nome"));
				bean.setCognome(rs.getString("cognome"));
				bean.setEmail(rs.getString("email"));
				bean.setQuantita(rs.getInt("quantita"));
				bean.setPrezzoTot(rs.getFloat("prezzoTot"));

				all_orders.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return all_orders;

	}

	@Override
	public int idLastOrder() throws SQLException {
		int idOrdine = -1;
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT idOrdine FROM " + OrderDAOImp.TABLE_NAME + " ORDER BY idOrdine DESC LIMIT 1";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				idOrdine = rs.getInt("idOrdine");
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
		return idOrdine;
	}
	
	private static final String TABLE_NAME = "ordine";

	private DataSource ds;


}
