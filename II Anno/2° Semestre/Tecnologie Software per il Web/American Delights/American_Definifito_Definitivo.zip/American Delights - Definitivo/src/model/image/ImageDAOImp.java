package model.image;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import model.product.ProductBean;

public class ImageDAOImp implements ImageDAO {

	public ImageDAOImp() {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/american");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}

	@Override
	public synchronized void doSave(ImageBean image) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO " + ImageDAOImp.TABLE_NAME
				+ " (pathname, idProdotto, predefinito)"
				+ " VALUES (?, ?, ?)";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setString(1, image.getPathname());
			preparedStatement.setInt(2, image.getIdProdotto());
			preparedStatement.setBoolean(3, image.isPredefinito());

			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}

	@Override
	public synchronized ImageBean doRetrieveByKey(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ImageBean bean = new ImageBean();

		String selectSQL = "SELECT * FROM " + ImageDAOImp.TABLE_NAME + " WHERE idImmagine = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, code);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				bean.setId(rs.getInt("idImmagine"));
				bean.setPathname(rs.getString("pathname"));
				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setPredefinito(rs.getBoolean("predefinito"));
				
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}

	@Override
	public synchronized boolean doDelete(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		String deleteSQL = "DELETE FROM " + ImageDAOImp.TABLE_NAME + " WHERE idImmagine = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1,code);

			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}

	@Override
	public synchronized Collection<ImageBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<ImageBean> images = new LinkedList<ImageBean>();

		String selectSQL = "SELECT * FROM " + ImageDAOImp.TABLE_NAME;

		if (order != null && !order.equals("")) {
			selectSQL += " ORDER BY " + order;
		}

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ImageBean bean = new ImageBean();
				bean.setId(rs.getInt("idImmagine"));
				bean.setPathname(rs.getString("pathname"));
				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setPredefinito(rs.getBoolean("predefinito"));
				images.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return images;
	}
	
	@Override
	public Collection<ImageBean> getImagesByProdotto(int idProdotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<ImageBean> images = new LinkedList<ImageBean>();

		String selectSQL = "SELECT * FROM immagini WHERE idProdotto = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1,idProdotto);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ImageBean bean = new ImageBean();
				bean.setId(rs.getInt("idImmagine"));
				bean.setPathname(rs.getString("pathname"));
				bean.setIdProdotto(rs.getInt("idProdotto"));
				bean.setPredefinito(rs.getBoolean("predefinito"));
				images.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return images;
	}
	
	public boolean isImage(int idProdotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM immagini WHERE idProdotto = "+idProdotto;

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			boolean flag = false;
			while (rs.next()) {
				flag = true;
			}
			
			if(!flag) {
				return false;
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return true;
	}
	
	private static final String TABLE_NAME = "immagini";
	
	private DataSource ds;

	
}
