package model.carte;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import model.carte.CarteDAO;

public class CarteDAOImp implements CarteDAO {

	public CarteDAOImp() {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/american");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}


	@Override
	public boolean cartaEsistente(String nCarta) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM registrocarte WHERE nCarta = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, nCarta);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				return true;				
			}
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return false;
	}

	public void effettuaPagamento(String nCarta, float spesa) throws SQLException {
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			
			String updateSQL = "UPDATE registrocarte SET saldo=saldo-? WHERE nCarta=?";

			try {
				connection = ds.getConnection();
				preparedStatement = connection.prepareStatement(updateSQL);
				preparedStatement.setFloat(1,spesa);
				preparedStatement.setString(2,nCarta);

				preparedStatement.executeUpdate();
				
				connection.commit();

			} finally {
				try {
					if (preparedStatement != null)
						preparedStatement.close();
				} finally {
					if (connection != null)
						connection.close();
				}
			}
	}
	
	private DataSource ds;

	@Override
	public boolean pagamentoPossibile(String nCarta, float spesa) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT saldo FROM registrocarte WHERE nCarta = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, nCarta);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				float saldo = rs.getFloat("saldo");
				if( saldo>=spesa ) {
					return true;
				}				
			}
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return false;
	}

}
