package model.composto;

import java.sql.SQLException;
import java.util.Collection;

public interface CompostoDAO {

	public void doSave(CompostoBean composto) throws SQLException;

	public Collection<CompostoBean> doRetrieveByOrderKey(int idOrdine) throws SQLException;
}
