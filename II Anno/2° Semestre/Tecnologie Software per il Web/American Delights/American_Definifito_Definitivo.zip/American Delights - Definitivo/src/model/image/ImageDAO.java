package model.image;

import java.sql.SQLException;
import java.util.Collection;

public interface ImageDAO {
	
	public void doSave(ImageBean image) throws SQLException;

	public boolean doDelete(int id) throws SQLException;

	public ImageBean doRetrieveByKey(int id) throws SQLException;
	
	public Collection<ImageBean> doRetrieveAll(String order) throws SQLException;

	public Collection<ImageBean> getImagesByProdotto(int idProdotto) throws SQLException;
	
	/**
	 * Ritorna true se esiste gi� un'immagine per un determinato prodotto, false altrimenti
	 * @param idProdotto
	 * @return
	 * @throws SQLException
	 */
	public boolean isImage(int idProdotto) throws SQLException;
}
