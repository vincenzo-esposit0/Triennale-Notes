package service;

import java.sql.SQLException;
import java.util.Collection;

import model.image.ImageBean;
import model.image.ImageDAOImp;
import model.product.ProductBean;
import model.product.ProductDAOImp;

/**
 * Effettua il collegamento da prodotti ed immagini
 * @author gerar
 *
 */
public class ProductAndImages {

	public ProductAndImages() {
		this.modelImage = new ImageDAOImp();
	}
	
	public void matchProductAndImages(ProductBean product) throws SQLException {
		Collection<ImageBean> immagini = modelImage.getImagesByProdotto(product.getId());
		product.setImmagini(immagini);
	}
	
	private ImageDAOImp modelImage;
}
