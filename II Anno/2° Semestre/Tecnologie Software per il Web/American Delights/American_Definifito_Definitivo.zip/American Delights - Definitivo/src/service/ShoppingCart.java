package service;

import java.util.ArrayList;

import model.product.ProductBean;

public class ShoppingCart {

	public ShoppingCart() {
		cart = new ArrayList<ProductItem>();
	}
	
	public boolean addProductItem(ProductItem prod)  {
		int quantitaBean = prod.getProduct().getQuantita();
		for(ProductItem product : cart) {
			if(prod.getId()==product.getId()) {
				if( product.getQuantita()>=quantitaBean ) {
					return false;
				}
				product.setQuantita( product.getQuantita()+1 );
				return true;
			}
		}
		
		if( prod.getQuantita()<=quantitaBean ) {
			cart.add(prod);
		} else {
			return false;
		}
		
		return true;
	}
	
	public void removeProductItem(int id) {
		for(int i=0; i<cart.size(); i++ ) {
			if( id == cart.get(i).getId() ) {
				if( cart.get(i).getQuantita() == 1) {
					cart.remove(i);
					return;
				}
				
				if( cart.get(i).getQuantita() > 1) {
					cart.get(i).setQuantita( cart.get(i).getQuantita() - 1 );
					return;
				}
			}
		}
		
	}
	
	/**
	 * Calcola il prezzo totale con applicazione di sconto ed iva
	 * @return prezzo totale
	 */
	public float getPrezzoTotale() {
		
		//Inizializzazione
		float tot=0;
		float prezzoTotItem=0;
		float iva=0;
		float sconto=0;
		float prezzo=0;
		ProductBean bean=null;
		
		for(ProductItem p:cart) {
			//Assegnamento inizializzazione per ogni item
			prezzoTotItem=0;
			bean = p.getProduct();
			sconto = bean.getSconto();
			prezzo = p.getPrezzo();
			
			iva = ( prezzo*bean.IVA )/100;
			prezzoTotItem = prezzo+iva;
			sconto=( prezzoTotItem*sconto )/100;
			
			prezzoTotItem=prezzoTotItem-sconto;
			
			tot+=prezzoTotItem*p.getQuantita();
			
		}
			
		return tot;
	}
	
	/**
	 * Ritorna la quantit� di elementi aggiunti al carrello
	 * @return
	 */
	public int getQuantita() {
		int quantita = 0;
		
		for(ProductItem product:cart) {
			quantita += product.getQuantita();
		}
		
		return quantita;
	}
	
	public ArrayList<ProductItem> getProducts() {
		return this.cart;
	}
	
	private ArrayList<ProductItem> cart;
}
