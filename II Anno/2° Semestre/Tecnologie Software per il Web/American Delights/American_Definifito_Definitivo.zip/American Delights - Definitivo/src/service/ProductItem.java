package service;

import model.product.ProductBean;

public class ProductItem {

	public ProductItem(ProductBean product) {
		this.product = product;
		this.quantita = 1;
	}
	
	public int getId() {
		return this.product.getId();
	}
	
	public String getNome() {
		return this.product.getNome();
	}
	
	public float getPrezzo() {
		return this.product.getPrezzo();
	}
	
	public ProductBean getProduct() {
		return product;
	}
	public void setProduct(ProductBean product) {
		this.product = product;
	}
	public int getQuantita() {
		return quantita;
	}
	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}

	public boolean equals(Object obj) {
		return product.equals(obj);
	}

	private ProductBean product;
	private int quantita;
}
