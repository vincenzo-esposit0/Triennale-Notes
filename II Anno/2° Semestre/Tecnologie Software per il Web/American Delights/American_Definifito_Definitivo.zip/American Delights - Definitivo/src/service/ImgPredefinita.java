package service;

import java.util.Collection;

import model.image.ImageBean;

public class ImgPredefinita {

	public ImgPredefinita() {
		
	}
	
	/**
	 * Ritorna l'immagine predefinita di un prodotto
	 * @param imgs
	 * @return
	 */
	public ImageBean getPredefinita(Collection<ImageBean> imgs) {
		if( imgs==null ) {
			return null;
		}
      	  for( ImageBean img:imgs ) {
    		if( img.isPredefinito() ) {
    			return img;
    		}
        }
      	  
      	return null;
	}
}
