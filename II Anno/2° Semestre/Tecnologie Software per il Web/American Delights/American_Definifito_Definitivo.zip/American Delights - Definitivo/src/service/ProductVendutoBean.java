package service;
import model.product.*;

public class ProductVendutoBean {

	
	public ProductBean getProduct() {
		return product;
	}
	public void setProduct(ProductBean product) {
		this.product = product;
	}
	public int getQuantitaVen() {
		return quantitaVen;
	}
	public void setQuantitaVen(int quantitaVen) {
		this.quantitaVen = quantitaVen;
	}
	public float getIvaVen() {
		return ivaVen;
	}
	public void setIvaVen(float ivaVen) {
		this.ivaVen = ivaVen;
	}
	public float getScontoVen() {
		return scontoVen;
	}
	public void setScontoVen(float scontoVen) {
		this.scontoVen = scontoVen;
	}
	public float getPrezzoVen() {
		return prezzoVen;
	}
	public void setPrezzoVen(float prezzoVen) {
		this.prezzoVen = prezzoVen;
	}
	private ProductBean product;
	private int quantitaVen;
	private float ivaVen, scontoVen, prezzoVen;
}
