package control.product;

import java.io.IOException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.image.ImageBean;
import model.image.ImageDAOImp;
import model.product.ProductBean;
import model.product.ProductDAOImp;

import service.ProductAndImages;

/**
 * Servlet implementation class ProductControl
 */
@SuppressWarnings("serial")
@WebServlet("/shop")
public class ProductControl extends HttpServlet {

	public ProductControl() {
		super();
		this.modelProduct = new ProductDAOImp();
		this.modelImage = new ImageDAOImp();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("page","prodotti");
		
		String idCategoria = request.getParameter("idCategoria");
		
		try {
			if (idCategoria != null) {
				Collection<ProductBean> prodotti = modelProduct.getProductByIdCategory( Integer.parseInt( idCategoria ) );

				ProductAndImages match = new ProductAndImages();
				
				for(ProductBean p:prodotti) {
					match.matchProductAndImages(p);
				}
				
				request.setAttribute("prodotti",prodotti);
			}
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}

		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/shop.jsp");
		dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doGet(request, response);
	}
	
	private static final long serialVersionUID = 1L;
	private ProductDAOImp modelProduct;
	private ImageDAOImp modelImage;

}
