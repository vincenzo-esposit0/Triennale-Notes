package control.order;

import java.io.IOException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.order.OrderBean;
import model.order.OrderDAOImp;
import model.user.UserBean;
import model.composto.*;
import model.product.*;
import service.ProductVendutoBean;


/**
 * Servlet implementation class OrderControl
 */
@SuppressWarnings("serial")
@WebServlet("/order")
public class OrderControl extends HttpServlet {

	public OrderControl() {
		super();
		this.modelOrder = new OrderDAOImp();
		this.modelComposto = new CompostoDAOImp();
		this.modelProduct = new ProductDAOImp();
		//this.modelImage = new ImageDAOImp();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		/**
		 * Prelevo l'id dell'utente dalla sessione
		 */
		UserBean user = (UserBean) request.getSession().getAttribute("user");
		if( user==null ) {
			String redirectedPage = "/index";
			response.sendRedirect(request.getContextPath() + redirectedPage);
			return;
		}

		String idOrdine = request.getParameter("idOrdine");

		try {
			if (idOrdine == null) {
				request.setAttribute("page","listaOrdini");
				Collection<OrderBean> orders = modelOrder.doRetrieveAll( user.getId());
				request.setAttribute("ordini", orders);
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/order_list.jsp");
				dispatcher.forward(request, response);
				return;
			}
			else {
				request.setAttribute("page","singoloOrdine");
				OrderBean order = (OrderBean) modelOrder.doRetrieveSingleOrder(Integer.parseInt(idOrdine));
				Collection<ProductVendutoBean> prVen = new LinkedList<ProductVendutoBean>();
				Collection<CompostoBean> composto = (Collection<CompostoBean>) modelComposto.doRetrieveByOrderKey(Integer.parseInt(idOrdine));
				for(CompostoBean comp : composto) {
					ProductBean prodotto = (ProductBean) modelProduct.doRetrieveByKey(comp.getIdProdotto());
					ProductVendutoBean bean = new ProductVendutoBean();
					bean.setProduct(prodotto);
					bean.setPrezzoVen(comp.getPrezzo());
					bean.setIvaVen(comp.getIva());
					bean.setQuantitaVen(comp.getQuantita());
					bean.setScontoVen(comp.getSconto());
					prVen.add(bean);
	    		}

				request.setAttribute("ordine", order);
				request.setAttribute("prodVen", prVen);
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/single_order.jsp");
				dispatcher.forward(request, response);
			}
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	private static final long serialVersionUID = 1L;
	private OrderDAOImp modelOrder;
	private CompostoDAOImp modelComposto;
	private ProductDAOImp modelProduct;

}
