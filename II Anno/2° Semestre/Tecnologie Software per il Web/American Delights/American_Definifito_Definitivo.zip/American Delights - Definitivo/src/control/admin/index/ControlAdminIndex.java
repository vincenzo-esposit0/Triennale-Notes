package control.admin.index;

import java.io.IOException;

import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.image.ImageBean;
import model.image.ImageDAOImp;
import model.product.ProductBean;
import model.product.ProductDAOImp;
import model.user.UserBean;
import service.ProductAndImages;

/**
 * Servlet implementation class ProductControl
 */
@SuppressWarnings("serial")
@WebServlet("/admin/dashboard/index")
public class ControlAdminIndex extends HttpServlet {

	public ControlAdminIndex() {
		super();
		this.modelProduct = new ProductDAOImp();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//Controllo se ci sono i permessi di amministrazione
		UserBean user = (UserBean) request.getSession().getAttribute("user");
		
		if( user==null ) {
			String redirectedPage = "/401.jsp";
			response.sendRedirect(request.getContextPath() + redirectedPage);
			return;
		}
		else if( !user.isAdmin() ) {
			String redirectedPage = "/401.jsp";
			response.sendRedirect(request.getContextPath() + redirectedPage);
			return;
		}
				
		request.setAttribute("pageControl","indexAdmin");
		try {
			Collection<ProductBean> prodotti = modelProduct.doRetrieveMostOrder();
			
			request.setAttribute("prodotti",prodotti);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}

		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/dashboard/index.jsp");
		dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doGet(request, response);
	}
	
	private static final long serialVersionUID = 1L;
	private ProductDAOImp modelProduct;

}