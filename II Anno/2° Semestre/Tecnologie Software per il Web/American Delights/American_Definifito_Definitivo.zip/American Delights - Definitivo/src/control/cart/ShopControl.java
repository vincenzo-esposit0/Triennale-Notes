package control.cart;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import model.product.ProductBean;
import model.product.ProductDAOImp;
import service.ProductAndImages;
import service.ProductItem;
import service.ShoppingCart;

/**
 * Servlet implementation class ProductControl
 */
@SuppressWarnings("serial")
@WebServlet("/cart")
public class ShopControl extends HttpServlet {

	public ShopControl() {
		super();
		this.model = new ProductDAOImp();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//Per gestione pagine
		request.setAttribute("page","shop");
		
		ShoppingCart cart = (ShoppingCart) request.getSession().getAttribute("cart");
		if(cart == null) {
			cart = new ShoppingCart();
			request.getSession().setAttribute("cart", cart);
		}
		
		String action = request.getParameter("action");
		
		//JSON
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		Gson json = new Gson();
		String jsonMessage = "";
		
		try {
			if (action != null) {
				if (action.equalsIgnoreCase("read")) {
					
					int idProdotto = Integer.parseInt(request.getParameter("idProdotto"));
					request.removeAttribute("product");
					request.setAttribute("product", model.doRetrieveByKey(idProdotto));
	
				}
				else if (action.equalsIgnoreCase("add")) {
					
					int idProdotto = Integer.parseInt(request.getParameter("idProdotto"));
					
					ProductBean bean = (ProductBean) model.doRetrieveByKey(idProdotto);
					
					ProductItem prod = new ProductItem(bean);
			    	if( !cart.addProductItem(prod) ) {
			    		jsonMessage = "{\"message\":\"Hai superato la quantit� massima!\"}";
			    		response.setStatus(400);
			    	}
			    	else {
			    		//Carico le img del prodotto
			    		ProductAndImages match = new ProductAndImages();
						match.matchProductAndImages(bean);
						
			    		jsonMessage = "{\"message\":\"Prodotto aggiunto con successo al carrello!\"}";
						response.setStatus(200);
			    	}
			    	
					String jsonString = json.toJson(jsonMessage);
					
					out.print(jsonString);
					out.flush();
					return;
					
				}
				else if (action.equalsIgnoreCase("delete")) {
					
					int idProdotto = Integer.parseInt(request.getParameter("idProdotto"));
					
			    	cart.removeProductItem(idProdotto);
					
				}
			}
		} catch (SQLException e) {
			jsonMessage = "{\"message\":\"Errore da parte della banca dati!\"}";
			String jsonString = json.toJson(jsonMessage);
			response.setStatus(400);
			
			out.print(jsonString);
			out.flush();
			return;
		}
		
		request.getSession().setAttribute("cart", cart);
		request.setAttribute("cart", cart);

		try {
			request.removeAttribute("products");
			request.setAttribute("products", model.doRetrieveAll(null));
		} catch (SQLException e) {
			jsonMessage = "{\"message\":\"Errore da parte della banca dati!\"}";
			String jsonString = json.toJson(jsonMessage);
			
			out.print(jsonString);
			out.flush();
			return;
		}
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/shoppingCart.jsp");
		dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doGet(request, response);
	}
	
	private static final long serialVersionUID = 1L;
	private ProductDAOImp model;

}
