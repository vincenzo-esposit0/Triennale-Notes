package control.admin.product;

import java.io.IOException;

import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.categoria.CategoriaBean;
import model.categoria.CategoriaDAOImp;
import model.image.ImageBean;
import model.image.ImageDAOImp;
import model.product.ProductBean;
import model.product.ProductDAOImp;

import service.ProductAndImages;

/**
 * Servlet implementation class ProductControl
 */
@SuppressWarnings("serial")
@WebServlet("/admin/dashboard/productAdmin")
public class ProductAdminControl extends HttpServlet {

	public ProductAdminControl() {
		super();
		this.modelProduct = new ProductDAOImp();
		this.modelCategory = new CategoriaDAOImp();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("pageControl","productsAdmin");
		
		String page = (String) request.getParameter("page");
		
		if( page!=null ) {
			if( page.equalsIgnoreCase("products") )
			{
				try {
					Collection<ProductBean> prodotti = modelProduct.doRetrieveAll(null);
					
					request.setAttribute("prodotti",prodotti);
				} catch (SQLException e) {
					response.setStatus(400);
					response.getWriter().append("Errore "+e);
				}
			} 
			else if( page.equalsIgnoreCase("updateProduct") ) {
				String idProdotto = request.getParameter("idProdotto");
				if( idProdotto!=null ) {
					try {
						ProductBean product = modelProduct.doRetrieveByKey( Integer.parseInt(idProdotto) );
						
						//Recupero anche la categoria del prodotto
						CategoriaBean category = modelCategory.doRetrieveByKey( product.getIdCategoria() );
						
						request.setAttribute("prodotto",product);
						request.setAttribute("categoria",category);
					} catch (SQLException e) {
						e.printStackTrace();
						response.setStatus(400);
						response.getWriter().append("Errore "+e);
					}
				}
				
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/dashboard/updateProduct.jsp");
				dispatcher.forward(request, response);
				return;
			}
			else if( page.equalsIgnoreCase("deleteProduct") ) {
				String idProduct = request.getParameter("idProdotto");
				
				if( idProduct!=null ) {
					try {
						modelProduct.doDelete( Integer.parseInt(idProduct) );
					} catch (NumberFormatException e) {
						response.setStatus(400);
						response.getWriter().append("Errore "+e);
					} catch (SQLException e) {
						e.printStackTrace();
						response.setStatus(400);
						response.getWriter().append("Errore "+e);
					}
				}
			}
		}

		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/dashboard/products.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String page = (String) request.getParameter("page");
		System.out.println("qui");
		
		if( page.equalsIgnoreCase("addProduct") ) {
			try {		
				String nome = request.getParameter("nome");
				String formato = request.getParameter("formato")+request.getParameter("tipoFormato");
				String ingredienti = request.getParameter("ingredienti");
				String infoAllergeni = request.getParameter("infoAllergeni");
				String valoriNutrizionali = request.getParameter("valoriNutrizionali");
				int prezzo = Integer.parseInt(request.getParameter("prezzo"));
				int sconto = Integer.parseInt(request.getParameter("sconto"));
				boolean glutine= Boolean.parseBoolean(request.getParameter("glutine"));
				int idCategoria = Integer.parseInt(request.getParameter("idCategoria"));
				int quantita = Integer.parseInt(request.getParameter("quantita"));
				
				
				model.product.ProductBean bean = new ProductBean();
				bean.setNome(nome);
				bean.setFormato(formato);
				bean.setIngredienti(ingredienti);
				bean.setInfoAllergeni(infoAllergeni);
				bean.setValoriNutrizionali(valoriNutrizionali);
				bean.setPrezzo(prezzo);
				bean.setSconto(sconto);
				bean.setGlutine(glutine);
				bean.setIdCategoria(idCategoria);
				bean.setQuantita(quantita);
				
				modelProduct.doSave(bean);
				
			} catch (SQLException e) {
				response.setStatus(400);
				response.getWriter().append("Errore "+e);
			}
		}
		
		response.sendRedirect("./productAdmin?page=products");
	}
	
	private static final long serialVersionUID = 1L;
	private ProductDAOImp modelProduct;
	private CategoriaDAOImp modelCategory;

}
