package control.admin.category;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.categoria.CategoriaBean;
import model.categoria.CategoriaDAOImp;
import model.product.ProductBean;
import model.user.UserBean;


/**
 * Servlet implementation class CategoryAdminControl
 */
@WebServlet("/admin/dashboard/category_list")
public class CategoryAdminControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CategoryAdminControl() {
        super();
        this.modelCategoria = new CategoriaDAOImp();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setAttribute("pageControl","categorie");
		
		//Controllo se ci sono i permessi di amministrazione
		UserBean user = (UserBean) request.getSession().getAttribute("user");
		
		if( user==null ) {
			String redirectedPage = "/401.jsp";
			response.sendRedirect(request.getContextPath() + redirectedPage);
			return;
		}
		else if( !user.isAdmin() ) {
			String redirectedPage = "/401.jsp";
			response.sendRedirect(request.getContextPath() + redirectedPage);
			return;
		}
				
		try {
			String action = request.getParameter("action");
			
			if( action!=null ) {
				if( action.equalsIgnoreCase("delete") ) {
					String idCategoria = request.getParameter("idCategoria");
					if( idCategoria!=null ) {
						modelCategoria.doDelete( Integer.parseInt(idCategoria) );
					}
				}
			}
			
			Collection<CategoriaBean> categorie = modelCategoria.doRetrieveAll(null);
			
			request.setAttribute("categorie", categorie);
			
			
		} catch (SQLException e) {
			response.setStatus(400);
			response.getWriter().append("Errore "+e);
		}
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/dashboard/categories.jsp");
		dispatcher.forward(request, response);
	} 

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String page = (String) request.getParameter("page");
		
		if(page!=null) {
			if( page.equalsIgnoreCase("addCategoria") ) {
				try {		
					String descrizione = request.getParameter("descrizione");
					
					
					model.categoria.CategoriaBean bean = new CategoriaBean();
					bean.setDescrizione(descrizione);
					
					modelCategoria.doSave(bean);
					
				} catch (SQLException e) {
					response.setStatus(400);
					response.getWriter().append("Errore "+e);
				}
			}
		}
		
		response.sendRedirect("./category_list");
	}

	private CategoriaDAOImp modelCategoria;
}
