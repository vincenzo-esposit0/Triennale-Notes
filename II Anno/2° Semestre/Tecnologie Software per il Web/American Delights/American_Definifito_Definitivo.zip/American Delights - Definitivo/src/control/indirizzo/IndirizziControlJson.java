package control.indirizzo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import model.indirizzo.IndirizzoBean;
import model.indirizzo.IndirizzoDAOImp;
import model.user.UserBean;

@WebServlet("/indirizzi_user_json")
public class IndirizziControlJson extends HttpServlet {
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IndirizziControlJson() {
        super();
        this.model = new IndirizzoDAOImp();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserBean user = (UserBean) request.getSession().getAttribute("user");
		
		//Preparo la risposta
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		Gson json = new Gson();
		
		String jsonMessage = null;
		String jsonString = null;
		
		if( user==null ) {
			response.setStatus(401);
			jsonMessage = "{\"message\":\"Non autorizzato!\"}";
			jsonString = json.toJson(jsonMessage);
		}
		try {
			Collection<IndirizzoBean> indirizzi = model.getIndirizzoByIdUser(user.getId());
			if( indirizzi!=null ) {
				jsonString = json.toJson(indirizzi);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			response.setStatus(400);
			jsonMessage = "{\"message\":\""+e+"\"}";
			jsonString = json.toJson(jsonMessage);
		}
		
		out.print(jsonString);
		out.flush();
		return;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private static final long serialVersionUID = 1L;
	private IndirizzoDAOImp model;

}
