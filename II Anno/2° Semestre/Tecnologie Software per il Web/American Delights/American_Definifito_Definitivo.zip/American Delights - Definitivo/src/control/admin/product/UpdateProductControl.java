package control.admin.product;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import model.image.ImageBean;
import model.image.ImageDAOImp;
import model.product.ProductBean;
import model.product.ProductDAOImp;

/**
 * Servlet implementation class AddProductControl
 */
@WebServlet("/admin/dashboard/UpdateProduct")
public class UpdateProductControl extends HttpServlet {
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProductControl() {
        super();
        this.model = new ProductDAOImp();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("pageControl","updateProduct");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {	
			String idProduct = request.getParameter("idProduct");
			String nome = request.getParameter("nome");
			String formato = request.getParameter("formato")+request.getParameter("tipoFormato");
			String ingredienti = request.getParameter("ingredienti");
			String infoAllergeni = request.getParameter("infoAllergeni");
			String valoriNutrizionali = request.getParameter("valoriNutrizionali");
			float prezzo = Float.parseFloat(request.getParameter("prezzo"));
			int sconto = Integer.parseInt(request.getParameter("sconto"));
			boolean glutine= Boolean.parseBoolean(request.getParameter("glutine"));
			int idCategoria = Integer.parseInt(request.getParameter("idCategoria"));
			int quantita = Integer.parseInt(request.getParameter("quantita"));
			
	
			model.product.ProductBean bean = new ProductBean();
			bean.setId(Integer.parseInt(idProduct));
			bean.setNome(nome);
			bean.setFormato(formato);
			bean.setIngredienti(ingredienti);
			bean.setInfoAllergeni(infoAllergeni);
			bean.setValoriNutrizionali(valoriNutrizionali);
			bean.setPrezzo(prezzo);
			bean.setSconto(sconto);
			bean.setGlutine(glutine);
			bean.setIdCategoria(idCategoria);
			bean.setQuantita(quantita);
			
			model.doUpdate(bean);
			
			response.sendRedirect("./productAdmin?page=products");
			
		} catch (SQLException e) {
			response.setStatus(400);
			response.getWriter().append("Errore "+e);
		}
	}
	
	private static final long serialVersionUID = 1L;
	private ProductDAOImp model;

}


