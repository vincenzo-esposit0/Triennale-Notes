package control.indirizzo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.indirizzo.IndirizzoBean;
import model.indirizzo.IndirizzoDAOImp;
import model.user.UserBean;

@WebServlet("/indirizzo")
public class IndirizzoControl extends HttpServlet {
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IndirizzoControl() {
        super();
        this.model = new IndirizzoDAOImp();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("page","indirizzoPage");
		
		UserBean user = (UserBean) request.getSession().getAttribute("user");
		
		if( user==null ) {
			String redirectedPage = "/index";
			response.sendRedirect(request.getContextPath() + redirectedPage);
			return;
		}
		try {
			//Se c'� un'azione di delete
			String action = request.getParameter("action");
			
			if( action!=null ) {
				if( action.equalsIgnoreCase("delete") ) {
					String idIndirizzo = request.getParameter("idIndirizzo");
					if( idIndirizzo!=null ) {
						model.doDelete( Integer.parseInt(idIndirizzo) );
					}
				}
			}
			
			Collection<IndirizzoBean> indirizzi = model.getIndirizzoByIdUser(user.getId());
			if( indirizzi!=null ) {
				request.setAttribute("indirizzi", indirizzi);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			response.setStatus(400);
			response.getWriter().append("Errore: "+e);
		}
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/indirizzi.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserBean user = (UserBean) request.getSession().getAttribute("user");
		request.setAttribute("page","indirizzoPage");
		
		if( user==null ) {
			String redirectedPage = "/index";
			response.sendRedirect(request.getContextPath() + redirectedPage);
		}
		String via = request.getParameter("via");
		String nCivico = request.getParameter("nCivico");
		String citta = request.getParameter("citta");
		String provincia = request.getParameter("provincia");
		String cap = request.getParameter("cap");
		String descrizione = request.getParameter("descrizione");
		
		IndirizzoBean indirizzo = new IndirizzoBean();
		
		indirizzo.setVia(via);
		indirizzo.setNCivico(nCivico);
		indirizzo.setCitta(citta);
		indirizzo.setProvincia(provincia);
		indirizzo.setCap(cap);
		indirizzo.setDescrizione(descrizione);
		indirizzo.setIdUtente(user.getId());
		
		
		try {
			if(user!=null) {
				model.doSave(indirizzo);
				request.getSession(true);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			response.setStatus(400);
			response.getWriter().append("Errore: "+e);
		}
		
		doGet(request, response);
	}
	
	private static final long serialVersionUID = 1L;
	private IndirizzoDAOImp model;

}
