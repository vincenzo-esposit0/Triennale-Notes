package control.image;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.image.ImageDAOImp;

/**
 * Servlet implementation class ImageControl
 */
@WebServlet("/getImage")
public class ImageControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ImageControl() {
        super();
        
        this.model = new ImageDAOImp();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String page = (String) request.getParameter("page");
		String idProdotto = (String) request.getParameter("idProdotto");
		
		if( ( page != null ) && ( idProdotto != null ) ) {
			if( page.equalsIgnoreCase("singleImage") ) {
				try {
					model.getImagesByProdotto( Integer.parseInt( idProdotto ) );
				} catch (NumberFormatException | SQLException e) {
					response.setStatus(400);
					response.getWriter().append("Errore: parametro non corretto!");
				}
			}
			else if( page.equalsIgnoreCase("allImage") ) { //TODO
			}
			else {
				response.setStatus(400);
				response.getWriter().append("Errore: parametro non corretto!");
			}
		}
		
		RequestDispatcher view = request.getRequestDispatcher("/admin/dashboard/products.jsp");
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private ImageDAOImp model;

}
