package control.auth;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.*;

import model.user.UserBean;
import model.user.UserDAOImp;


@SuppressWarnings("serial")
@WebServlet("/verify_email")
public class VerifyEmailControl extends HttpServlet {

	public VerifyEmailControl() {
		super();
		this.model = new UserDAOImp();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = request.getParameter("email");
		
		try {
			if( model.isEmail(email) ) {
				
				PrintWriter out = response.getWriter();
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				response.setStatus(409);
				
				Gson json = new Gson();
				
				String jsonMessage = "{\"error\":\"Email gi� esistente!\"}";
				String jsonString = json.toJson(jsonMessage);
				
				out.print(jsonString);
				out.flush();
				return;
			} else {
				
				response.setStatus(200);
				return;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static final long serialVersionUID = 1L;
	private UserDAOImp model;
}
