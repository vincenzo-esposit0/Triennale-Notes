package control.auth;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Base64;
import java.sql.Date;
import java.text.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.user.UserBean;
import model.user.UserDAOImp;

@SuppressWarnings("serial")
@WebServlet("/registrazione")
public class RegistrazioneControl extends HttpServlet {

	public RegistrazioneControl() {
		super();
		this.model = new UserDAOImp();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setAttribute("page","register");
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/register.jsp");
		dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String dataN = request.getParameter("dataNascita");
		
		UserBean user = new UserBean();
		
		Date dataNascita= java.sql.Date.valueOf(dataN);
		user.setDataNascita(dataNascita);
		
		Date dataRegistrazione = new java.sql.Date(System.currentTimeMillis());
		
		//Codifica della password
		Base64.Encoder enc = Base64.getEncoder();
		String encodedPass = enc.encodeToString(password.getBytes());
		
		user.setEmail(email);
		user.setPassword(encodedPass);
		user.setNome(nome);
		user.setCognome(cognome);
		user.setDataRegistrazione(dataRegistrazione);
		
		
		try {
			if(user!=null) {
				model.doSave(user);
				request.getSession(true);
				request.getSession().setAttribute("user",user);
				response.setStatus(200);
				
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/index.jsp");
				dispatcher.forward(request, response);
			}
		} catch (SQLException e) {
			System.out.println("Error: "+e.getMessage());
			return;
		}
		
	}
	
	private static final long serialVersionUID = 1L;
	private UserDAOImp model;
}
