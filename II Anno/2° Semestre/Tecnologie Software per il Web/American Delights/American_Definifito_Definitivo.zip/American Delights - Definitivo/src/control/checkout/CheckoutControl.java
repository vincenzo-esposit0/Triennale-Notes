package control.checkout;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.carte.CarteDAOImp;
import model.composto.CompostoBean;
import model.composto.CompostoDAOImp;
import model.indirizzo.IndirizzoBean;
import model.indirizzo.IndirizzoDAOImp;
import model.order.OrderBean;
import model.order.OrderDAOImp;
import model.product.ProductBean;
import model.product.ProductDAOImp;
import model.user.UserBean;
import service.ProductItem;
import service.ShoppingCart;

/**
 * Servlet implementation class CheckoutControl
 */
@WebServlet("/checkout")
public class CheckoutControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckoutControl() {
        super();
        
        this.modelOrder = new OrderDAOImp();
        this.modelComposto = new CompostoDAOImp();
        this.modelProduct = new ProductDAOImp();
        this.modelCarta = new CarteDAOImp();
        this.modelIndirizzo = new IndirizzoDAOImp();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ShoppingCart cart = (ShoppingCart) request.getSession().getAttribute("cart");
		if( cart!=null ) {
			if( cart.getQuantita()>0 ) {
				request.setAttribute("page","checkout");
				
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/checkout.jsp");
				dispatcher.forward(request, response);
			} else {
				response.sendRedirect("./index");
			}
		} else {
			response.sendRedirect("./index");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		try {
			
			String descrizione = request.getParameter("descrizione");
			String via = request.getParameter("via");
			String nCivico = (String) request.getParameter("nCivico");
			String citta = request.getParameter("citta");
			String provincia = request.getParameter("provincia");
			String cap = (String) request.getParameter("cap");
			String nome = request.getParameter("nome");
			String cognome = request.getParameter("cognome");
			String email = request.getParameter("email");
			String nCarta = (String) request.getParameter("nCarta");
			
			ShoppingCart cart = (ShoppingCart) request.getSession().getAttribute("cart");
			
			if( cart==null ) {
				request.setAttribute("error","Non hai elementi nel carrello per poter effettuare un ordine!");
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/error_checkout.jsp");
				dispatcher.forward(request, response);
				return;
			}
			else {
				//Controllo esistenza della carta
				if( !modelCarta.cartaEsistente(nCarta) ) {
					request.setAttribute("error","Errore: carta non esistente!");
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/error_checkout.jsp");
					dispatcher.forward(request, response);
					return;
				}
				
				//Controllo se � possibile effettuare il pagamento
				if( !modelCarta.pagamentoPossibile(nCarta, cart.getPrezzoTotale() ) ) {
					request.setAttribute("error","Errore: il saldo non � sufficiente!");
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/error_checkout.jsp");
					dispatcher.forward(request, response);
					return;
				}
				
				//Prendo l'id utente se � loggato
				UserBean user = (UserBean) request.getSession().getAttribute("user");
				
				//Calcolo la data corrente
				Date dataOrdine = new java.sql.Date(System.currentTimeMillis());
				
				OrderBean bean = new OrderBean();
				
				bean.setDataOrdine(dataOrdine);
				
				bean.setDescrizione(descrizione);
				if( user!=null ) {
					//Setto i dati dell'utente
					bean.setIdUtente( user.getId() );
					bean.setNome( user.getNome() );
					bean.setCognome( user.getCognome() );
					bean.setEmail( user.getEmail() );
					
					String idIndirizzo = (String) request.getParameter("idIndirizzo");
					
					//Prendo i dati dell'indirizzo scelto dall'utente
					if( idIndirizzo!=null ) {
						IndirizzoBean indirizzo = modelIndirizzo.doRetriveByKey( Integer.parseInt( idIndirizzo ) );
						bean.setVia( indirizzo.getVia() );
						bean.setnCivico( indirizzo.getNCivico() );
						bean.setCitta( indirizzo.getCitta() );
						bean.setProvincia( indirizzo.getProvincia() );
						bean.setCap( indirizzo.getCap() );
					}
				} else {
					bean.setVia(via);
					bean.setnCivico(nCivico);
					bean.setCitta(citta);
					bean.setProvincia(provincia);
					bean.setCap(cap);
					
					bean.setNome(nome);
					bean.setCognome(cognome);
					bean.setEmail(email);
				}
				
				bean.setStato("accettato");
				bean.setQuantita( cart.getQuantita() );
				bean.setPrezzoTot( cart.getPrezzoTotale() );
				
				try {
					modelOrder.doSave(bean);
				} catch (SQLException e) {
					e.printStackTrace();
					response.setStatus(400);
					response.getWriter().append("Errore: "+e);
					return;
				}
				
				int idLastOrder = modelOrder.idLastOrder();
				if( idLastOrder==-1 ) {
					request.setAttribute("error","Errore: nessun ordine nella banca dati!");
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/error_checkout.jsp");
					dispatcher.forward(request, response);
					return;
				}
				
				for( ProductItem product:cart.getProducts() ) {
					ProductBean beanProduct = product.getProduct();
					
					//Errore quantit�
					if( product.getQuantita() > beanProduct.getQuantita() ) {
						request.setAttribute("error","Qualcuno avr� fatto prima di te! Le quantit� selezionate non sono pi� disponibili.");
						RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/error_checkout.jsp");
						dispatcher.forward(request, response);
						return;
					}
					
					try {
						modelProduct.updateQuantita( product.getId(), product.getQuantita() );
					} catch (SQLException e) {
						e.printStackTrace();
						response.setStatus(400);
						response.getWriter().append("Errore: "+e);
						return;
					}
					
					CompostoBean composto = new CompostoBean();
					composto.setIdOrdine( idLastOrder );
					composto.setIdProdotto( product.getId() );
					composto.setQuantita( product.getQuantita() );
					composto.setPrezzo( product.getPrezzo() );
					composto.setIva( beanProduct.IVA );
					composto.setSconto( beanProduct.getSconto() );
					
					try {
						modelComposto.doSave( composto );
					} catch (SQLException e) {
						e.printStackTrace();
						response.setStatus(400);
						response.getWriter().append("Errore: "+e);
						return;
					}
					
					//Effettuo il pagamento
					modelCarta.effettuaPagamento(nCarta, cart.getPrezzoTotale() );
					
					//Resetto il carrello
					ShoppingCart carrello = null;
					request.getSession().removeAttribute("cart");
					request.getSession().setAttribute("cart", carrello);
				}
			}
						
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/thanks_page.jsp");
			dispatcher.forward(request, response);
			
		} catch (SQLException e) {
			e.printStackTrace();
			response.setStatus(400);
			response.getWriter().append("Errore: "+e);
			return;
		}
	}
	
	private OrderDAOImp modelOrder;
	private CompostoDAOImp modelComposto;
	private ProductDAOImp modelProduct;
	private CarteDAOImp modelCarta;
	private IndirizzoDAOImp modelIndirizzo;

}
