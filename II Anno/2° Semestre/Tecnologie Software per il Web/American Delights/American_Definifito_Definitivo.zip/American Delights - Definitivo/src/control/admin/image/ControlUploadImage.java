package control.admin.image;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import model.image.ImageBean;
import model.image.ImageDAOImp;

@MultipartConfig
@WebServlet("/admin/dashboard/insertImage")
public class ControlUploadImage extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("./productAdmin?page=products");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	    String appPath = request.getServletContext().getRealPath("");
	    String savePath = appPath + File.separator + SAVE_DIR;
	         
		File fileSaveDir = new File(savePath);
		if (!fileSaveDir.exists()) {
			fileSaveDir.mkdir();
		}

		for (Part part : request.getParts()) {
			String fileName = extractFileName(part);
			if (fileName != null && !fileName.equals("")) {
				part.write(savePath + File.separator + fileName);
				try {
					ImageBean bean = new ImageBean();
					bean.setPathname(SAVE_DIR +"/"+ fileName);
					
					String idProdotto = (String) request.getParameter("idProdotto");
					
					if( idProdotto==null ) {
						response.setStatus(400);
						response.getWriter().append("Errore: id del prodotto mancante");
					}
					
					bean.setIdProdotto( Integer.parseInt( idProdotto ) );
					ImageDAOImp model = new ImageDAOImp();
					
					if( !model.isImage( Integer.parseInt( idProdotto ) ) ) {
						bean.setPredefinito(true);
					}
					
					model.doSave(bean);
				} catch (SQLException e) {
					response.setStatus(400);
					response.getWriter().append("Errore: "+e);
				}
			}
		}

		response.sendRedirect("./productAdmin?page=products");
		
	}
	
	private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length()-1);
            }
        }
        return "";
    }		
	
	private static final long serialVersionUID = 1L;
	static String SAVE_DIR ="images";
}
