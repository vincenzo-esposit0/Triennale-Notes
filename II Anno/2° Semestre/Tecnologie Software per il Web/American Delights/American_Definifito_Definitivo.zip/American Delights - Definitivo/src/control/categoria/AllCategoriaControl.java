package control.categoria;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import model.categoria.CategoriaBean;
import model.categoria.CategoriaDAOImp;

/**
 * Servlet implementation class AllCategoriaControl
 */
@WebServlet("/admin/dashboard/getAllCategory")
public class AllCategoriaControl extends HttpServlet {
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AllCategoriaControl() {
        super();
        
        this.model = new CategoriaDAOImp();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Collection<CategoriaBean> categorie = model.doRetrieveAll(null);
			
			PrintWriter out = response.getWriter();
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			response.setStatus(200);
			
			Gson json = new Gson();
			
			String jsonString = json.toJson(categorie);
			
			out.print(jsonString);
			out.flush();
			return;
		} catch (SQLException e) {
			response.setStatus(400);
			response.getWriter().append("Errore "+e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private static final long serialVersionUID = 1L;
	private CategoriaDAOImp model;

}
