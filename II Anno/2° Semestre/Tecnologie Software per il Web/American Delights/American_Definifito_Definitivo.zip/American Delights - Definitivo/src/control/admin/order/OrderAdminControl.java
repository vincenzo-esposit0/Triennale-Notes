package control.admin.order;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Collection;

import model.order.OrderBean;
import model.order.OrderDAOImp;
import model.user.UserBean;


/**
 * Servlet implementation class OrderControl
 *
 */
@SuppressWarnings("serial")
@WebServlet("/admin/dashboard/order_list")
public class OrderAdminControl extends HttpServlet{

	public OrderAdminControl() {
		super();
		this.modelOrder = new OrderDAOImp();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("pageControl", "ordini");
		
		//Controllo se ci sono i permessi di amministrazione
		UserBean user = (UserBean) request.getSession().getAttribute("user");
		
		if( user==null ) {
			String redirectedPage = "/401.jsp";
			response.sendRedirect(request.getContextPath() + redirectedPage);
			return;
		}
		else if( !user.isAdmin() ) {
			String redirectedPage = "/401.jsp";
			response.sendRedirect(request.getContextPath() + redirectedPage);
			return;
		}

		try {
				Collection<OrderBean> order = (Collection<OrderBean>) modelOrder.doRetrieveAll();


				request.setAttribute("ordini", order);

		} catch (SQLException e) {
			response.setStatus(400);
			response.getWriter().append("Errore "+e);
			return;
		}

		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/dashboard/orders.jsp");
		dispatcher.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	private OrderDAOImp modelOrder;

}
