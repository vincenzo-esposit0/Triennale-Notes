package control.product;

import java.io.IOException;

import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.categoria.CategoriaBean;
import model.categoria.CategoriaDAOImp;
import model.image.ImageDAOImp;
import model.product.ProductBean;
import model.product.ProductDAOImp;
import service.ProductAndImages;

/**
 * Servlet implementation class ProductControl
 */
@SuppressWarnings("serial")	
@WebServlet("/single_product")
public class SingolProductControl extends HttpServlet {

	public SingolProductControl() {
		super();
		this.modelProduct = new ProductDAOImp();
		this.modelCategoria = new CategoriaDAOImp();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("page","prodotti");
		
		String idProdotto = request.getParameter("idProdotto");
		
		try {
			if (idProdotto != null) {
				ProductBean prodotto = modelProduct.doRetrieveByKey(Integer.parseInt( idProdotto ));
				
				if( prodotto!=null ) {
					CategoriaBean categoria = modelCategoria.doRetrieveByKey( prodotto.getIdCategoria() );
					request.setAttribute("categoria", categoria);
				}
				
				ProductAndImages match = new ProductAndImages();
				
				match.matchProductAndImages(prodotto);
				

				request.setAttribute("prodotto", prodotto);
			}
		} catch (SQLException e) {
			response.setStatus(400);
			response.getWriter().append("Errore "+e);
		}

		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/single_product.jsp");
		dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doGet(request, response);
	}
	
	private static final long serialVersionUID = 1L;
	private ProductDAOImp modelProduct;
	private CategoriaDAOImp modelCategoria;

}