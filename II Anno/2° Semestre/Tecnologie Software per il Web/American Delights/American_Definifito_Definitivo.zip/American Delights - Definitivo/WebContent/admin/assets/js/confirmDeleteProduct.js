function confirmDeleteProduct(obj) {
	var idProduct = $(obj).attr("data-id");
	
	//Salvo id del prodotto da eliminare nell'input hidden
	$('#hiddenDelete').attr("value",obj.getAttribute('data-id'));
	
	var idElement = document.getElementById('titleDeleteProduct');
	if( (idElement!=null) && (idElement!=undefined) ) {
		$(idElement).html("Sei sicuro di voler eliminare il prodotto con id "+idProduct+"?");
	}
}