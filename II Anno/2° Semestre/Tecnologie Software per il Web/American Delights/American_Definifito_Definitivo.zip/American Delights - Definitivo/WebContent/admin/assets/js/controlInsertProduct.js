$(document).ready(function() {
	 $('#form_product').on("submit", function(e) {
	 e.preventDefault();
	 
	 var check = false;
    
    //Controllo sul nome
    var nome = document.getElementById("nome");
    if( ( nome.value.length <=1 ) || ( nome.value.length >25 ) ){
        nome.setAttribute("class","form-control is-invalid");
        $("#invalidNome").html("Il nome deve essere compreso tra i 2 e 25 caratteri!");
        check = true;
    }
	    
    //Controllo su ingredienti
    var ingredienti = document.getElementById("ingredienti");
    if( ( ingredienti.value.length <=1 )) {
        ingredienti.setAttribute("class","form-control is-invalid");
        $("#invalidIngredienti").html("Il contenuto della cella deve essere di almeno 2 caratteri!");
        check = true;
    }
    
  //Controllo su infoAllergeni
    var infoAllergeni = document.getElementById("infoAllergeni");
    if( ( infoAllergeni.value.length <=1 )) {
        infoAllergeni.setAttribute("class","form-control is-invalid");
        $("#invalidAllergeni").html("Il contenuto della cella deve essere di almeno 2 caratteri!");
        check = true;
    }
  
    //Controllo su valori nutrizionali
    var valoriNutrizionali = document.getElementById("valoriNutrizionali");
    if( ( valoriNutrizionali.value.length <=1 )) {
        valoriNutrizionali.setAttribute("class","form-control is-invalid");
        $("#invalidValori").html("Il contenuto della cella deve essere di almeno 2 caratteri!");
        check = true;
    }
   
    if(check) {
		 return false;
	 } else {
		 this.submit();
	 }

	 return true;
	    
	 });
});