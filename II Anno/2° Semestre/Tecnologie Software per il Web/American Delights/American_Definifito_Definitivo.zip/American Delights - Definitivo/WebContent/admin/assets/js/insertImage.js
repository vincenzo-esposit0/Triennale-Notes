function insertImage(obj) {
	
	var idProdotto = $(obj).attr('data-id');
	
	$('#imageHidden').attr('value',idProdotto);
}