function active(idPage) {
	document.getElementById(idPage).setAttribute("class","nav-link active");
}