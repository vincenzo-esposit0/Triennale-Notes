$(document).ready(function() {
    $.ajax({
       type: "GET",
       url: './getAllCategory',
       success: function(data, status)
       {
    	   if(status == 'success') {
    		   
    		   try{
    			   var i=0;
            	   data.map(element => {
            		   console.log(element);
            		   if(i==0) {
            			   $("#inputCategory").append('<option value='+element.id+' selected>'+element.descrizione+'</option>');
            		   }
            		   else {
            			   $("#inputCategory").append('<option value='+element.id+'>'+element.descrizione+'</option>');
            		   }
            		   i++;
            	   });
    		   }catch(error) {
    			   console.log(error);
    		   }
    	   }
       },
       error: function(data, status) {
    	   console.log("Error",data);
       }
    });
	 
});