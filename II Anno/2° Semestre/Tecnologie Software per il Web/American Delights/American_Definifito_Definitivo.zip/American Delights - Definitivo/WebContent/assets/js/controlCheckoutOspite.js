function controlForm(obj) {

	switch(obj.id) {
		case "nome":
			var nome = document.getElementById("nome");
		    if( ( nome.value.length <=1 ) || ( nome.value.length >25 ) || ( nome.value == "" ) ){
		    	nome.setAttribute("class","form-control is-invalid");
		    	$("#invalidNome").html("Il nome deve essere compreso tra i 2 e 25 caratteri!");
		    }
		    else {
		    	nome.setAttribute("class","form-control is-valid");
		    }
		 break;

		case "cognome":
			var cogn = document.getElementById("cognome");
		    if( ( cogn.value.length <=1 ) || ( cogn.value.length >25 ) || ( cogn.value == "" ) ){
		    	cogn.setAttribute("class","form-control is-invalid");
		    	$("#invalidCognome").html("Il cognome deve essere compreso tra i 2 e 25 caratteri!");
		    }
		    else {
		    	cogn.setAttribute("class","form-control is-valid");
		    }
		 break;

		case "email":
			var email_valid = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-]{2,})+.)+([a-zA-Z0-9]{2,})+$/;
			var email = document.getElementById("email");

		    if( !email_valid.test( email.value ) || ( email.value == "" ) ) {
		    	$('#email').attr("class","form-control is-invalid");
		    	$("#invalidEmail").html("Email non valida!");
		    }
		    else {
		    	email.setAttribute("class","form-control is-valid");
		    }
		 break;

		case "via":
			var via = document.getElementById("via");
		    if( ( via.value.length <=5 ) || (via.value.length > 40) || ( via.value == "" ) ){
		    	via.setAttribute("class","form-control is-invalid");
		    	$("#invalidVia").html("l'indirizzo non puo' essere inferirore a 1 carattere");
		    }
		    else {
		    	via.setAttribute("class","form-control is-valid");
		    }
		 break;

		case "nCivico":
			var civico = document.getElementById("nCivico");
		    if( ( civico.value.length <=1 ) || ( civico.value.length >5 ) || ( civico.value == "" ) ){
		    	civico.setAttribute("class","form-control is-invalid");
		    	$("#invalidnCivico").html("Non puo' essere inferiore di 1 carattere");
		    }
		    else {
		    	civico.setAttribute("class","form-control is-valid");
		    }
		 break;

		case "citta":
			var citta = document.getElementById("citta");
		    if( ( citta.value.length <=1 ) || ( citta.value.length >25 ) || ( citta.value == "" ) ){
		    	citta.setAttribute("class","form-control is-invalid");
		    	$("#invalidCitta").html("La citta' deve essere compresa tra i 2 e 25 caratteri!");
		    }
		    else {
		    	citta.setAttribute("class","form-control is-valid");
		    }
		 break;

		case "provincia":
			var provincia = document.getElementById("provincia");
		    if( ( provincia.value.length <=1 ) || ( provincia.value.length >25 ) || ( provincia.value == "" ) ){
		    	provincia.setAttribute("class","form-control is-invalid");
		    	$("#invalidProvincia").html("La provincia deve essere compresa tra i 2 e 25 caratteri!");
		    }
		    else {
		    	provincia.setAttribute("class","form-control is-valid");
		    }
		 break;

		case "cap":
			var cap = document.getElementById("cap");
		    if( ( cap.value.length != 5 ) || ( cap.value == "" ) ){
		    	cap.setAttribute("class","form-control is-invalid");
		    	$("#invalidCap").html("Il C.A.P. deve essere di 5 caratteri!");
		    }
		    else {
		    	cap.setAttribute("class","form-control is-valid");
		    }
		 break;
		 
		case "nCarta":
			var nCarta = document.getElementById("nCarta");
		    if( ( nCarta.value.length !=16 ) || ( nCarta.value == "" ) ){
		    	nCarta.setAttribute("class","form-control is-invalid");
		    	$("#invalidnCarta").html("Il numero della carta deve essere di 16 caratteri!");
		    }
		    else {
		    	nCarta.setAttribute("class","form-control is-valid");
		    }
		 break;


	}
}

$(document).ready(function() {
	  $('#form_checkout').on("submit", function(e) {
	  e.preventDefault();

      var check = false;

      //Controllo sul nome
      var nome = document.getElementById("nome");
      if( ( nome.value.length <=1 ) || ( nome.value.length >25 ) ){
          nome.setAttribute("class","form-control is-invalid");
          $("#invalidNome").html("Il nome deve essere compreso tra i 2 e 25 caratteri!");
          check = true;
      }

      //Controllo sul cognome
      var cogn = document.getElementById("cognome");
      if( ( cogn.value.length <=1 ) || ( cogn.value.length >25 ) ){
          cogn.setAttribute("class","form-control is-invalid");
          $("#invalidCognome").html("Il cognome deve essere compreso tra i 2 e 25 caratteri!");
          check = true;
      }

      //Controllo sull'email
      var email_valid = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-]{2,})+.)+([a-zA-Z0-9]{2,})+$/;
      var email = document.getElementById("email");
      if( !email_valid.test( email.value ) ) {
          $('#email').attr("class","form-control is-invalid");
          $("#invalidEmail").html("Email non valida!");
          check = true;
      }

      var via = document.getElementById("via");
      if( ( via.value.length <=5 ) || (via.value.length > 40) ){
	    	via.setAttribute("class","form-control is-invalid");
	    	$("#invalidVia").html("La deve essere compreso tra i 5 e i 40 caratteri!");
          	check = true;
      }


      var nCivico = document.getElementById("nCivico");
	  if( ( nCivico.value.length <1 ) || ( nCivico.value.length >7 ) ){
	   		nCivico.setAttribute("class","form-control is-invalid");
	    	$("#invalidNCivico").html("Il numero civico deve essere compreso tra 1 e 7 caratteri!");
	    	check = true;
	  }

		var citta = document.getElementById("citta");
		if( ( citta.value.length <=2 ) || ( citta.value.length >25) ){
		 	citta.setAttribute("class","form-control is-invalid");
		 	$("#invalidCitta").html("La cittÃ  deve essere copreso tra i 2 e i 25 caratteri!");
		 	check = true;
		 }

		var provincia = document.getElementById("provincia");
	    if( ( provincia.value.length <2 ) || ( provincia.value.length >25) ){
	    	provincia.setAttribute("class","form-control is-invalid");
	    	$("#invalidProvincia").html("La provincia deve essere copreso tra i 2 e i 25 caratteri!");
	    	check = true;
	    }

	    var cap = document.getElementById("cap");
	    if( cap.value.length != 5 ){
	    	cap.setAttribute("class","form-control is-invalid");
	    	$("#invalidCap").html("Il CAP deve essere 5 caratteri!");
	    	check = true;
	    }
	    
	    var nCarta = document.getElementById("nCarta");
	    if( nCarta.value.length !=16 ){
	    	nCarta.setAttribute("class","form-control is-invalid");
	    	$("#invalidnCarta").html("Il numero della carta deve essere di 16 caratteri!");
	    	check = true;
	    }
	  
		 if(check) {
			 return false;
		 }
		 else {
			 this.submit();
		 }


	 });

});