$(document).ready(function() {
    $.ajax({
       type: "GET",
       url: './indirizzi_user_json',
       success: function(data)
       {   
		   try{
			   var i=0;
        	   data.map(element => {
        		   console.log(element);
        		   if(i==0) {
        			   $("#inputIndirizzi").append('<option value='+element.id+' selected>'+
        					   "Città: "+element.citta+" - "+
        					   "Via: "+element.via+" - "+
        					   "n°: "+element.nCivico+" - "+
        					   "Pr: "+element.provincia+" - "+
        					   "CAP: "+element.cap
        					   +'</option>');
        		   }
        		   else {
        			   $("#inputIndirizzi").append('<option value='+element.id+'>'+
        					   "Città: "+element.citta+" - "+
        					   "Via: "+element.via+" - "+
        					   "n°: "+element.nCivico+" - "+
        					   "Pr: "+element.provincia+" - "+
        					   "CAP: "+element.cap
        					   +'</option>');
        		   }
        		   i++;
        	   });
		   }catch(error) {
			   console.log(error);
		   }
       },
       error: function(data, status) {
		   console.log(data);
       }
       
});
	 
});