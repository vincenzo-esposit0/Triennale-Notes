function creaPdf() {
	var doc = new jsPDF();
	
	doc.setTextColor(0, 255, 0);
	doc.text(20, 20, 'American Delights! - Esempio di fattura');
	doc.addPage();
	
	doc.setTextColor(0, 0, 0);
	doc.setFontType("bold");
	doc.text(20, 20, 'Dati del cliente: ');
    doc.addPage();
        
    doc.setFontType("bold");
	doc.text(20, 20, "Dati dell'ordine: ");
	doc.addPage();
	
    doc.setFontType("bold");
	doc.text(20, 20, 'Prodotti: ');

	doc.save('codingcreativo.pdf');
}