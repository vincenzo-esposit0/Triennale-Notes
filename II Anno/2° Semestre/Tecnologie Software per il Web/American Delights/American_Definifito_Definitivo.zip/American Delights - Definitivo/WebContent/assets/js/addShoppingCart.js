function addCart(obj) {
	$.ajax({
	       type: "GET",
	       url: './cart?action=add&idProdotto='+obj.getAttribute("data-id"),
	       success: function(data)
	       {
	    	   console.log("Aggiunto");
	    	   $.notify("Prodotto aggiunto!", "success");
	       },
	       error: function(data, status) {
	    	   if( data.status === 400 ) {
	    		   var json = JSON.parse(data.responseJSON);
	    		   $.notify(json.message, "error");
	    	   }
	       }
	   });
}