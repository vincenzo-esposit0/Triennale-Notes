
	//Funzione applicata alle immagini di classe fadein quando allo scroll siamo quasi vicino all'immagine
    function imgFadeIn(el) {

      //Altezza finestra
      var wh = $(window).height();

      //Ciclo le img con classe fadein
      $(el).each(function(){

        //Calcolo la posizione lungo l'asse verticale
        var thisPos = $(this).offset().top;

        //Calcolo la posizione attuale dello scroll
        var topOfWindow = $(window).scrollTop();

        //Calcoli per quando siamo "quasi" vicino all'immagine
        if (topOfWindow + wh - 200 > thisPos ) {
          $(this).addClass('fadein');
        }
      });
    }

    /*
    Lancio la funzione al verificarsi di alcuni eventi (scrolling e resize)
    legati alla finestra del browser
    */
    $(window).on('scroll resize', function() {

      imgFadeIn('.fadeimg'); //Effetto applicato alle immagini fadein

    });