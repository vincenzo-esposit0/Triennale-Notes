function controlForm() {
		var nCarta = document.getElementById("nCarta");
	    if( ( nCarta.value.length !=16 ) || ( nCarta.value == "" ) ){
	    	nCarta.setAttribute("class","form-control is-invalid");
	    	$("#invalidnCarta").html("Il numero della carta deve essere di 16 caratteri!");
	    }
	    else {
	    	nCarta.setAttribute("class","form-control is-valid");
	    }
}

$(document).ready(function() {
	  $('#form_checkout').on("submit", function(e) {
	  e.preventDefault();

      var check = false;
	    
	    var nCarta = document.getElementById("nCarta");
	    if( nCarta.value.length !=16 ){
	    	nCarta.setAttribute("class","form-control is-invalid");
	    	$("#invalidnCarta").html("Il numero della carta deve essere di 16 caratteri!");
	    	check = true;
	    }
	  
		 if(check) {
			 return false;
		 }
		 else {
			 this.submit();
		 }


	 });

});